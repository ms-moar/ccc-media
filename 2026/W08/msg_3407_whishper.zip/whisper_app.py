#!/usr/bin/env python3
"""
🎙️ WhisperApp — бесплатный клон MacWhisper
Транскрибация аудио и видео с помощью OpenAI Whisper.
Все модели, все языки, экспорт в любой формат.
"""

import os
import sys
import tempfile
import json
import time
import datetime
import gradio as gr
from pathlib import Path

# ---------------------------------------------------------------------------
# Lazy imports — heavy libs loaded only when needed
# ---------------------------------------------------------------------------
_model_cache = {}


def get_model(model_name: str):
    """Load or retrieve cached faster-whisper model."""
    if model_name not in _model_cache:
        from faster_whisper import WhisperModel

        # Determine device: use GPU if available, else CPU
        import torch
        if torch.cuda.is_available():
            device, compute = "cuda", "float16"
        elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            # Apple Silicon — faster-whisper doesn't support MPS directly,
            # but CTranslate2 can use CoreML or CPU int8 efficiently
            device, compute = "cpu", "int8"
        else:
            device, compute = "cpu", "int8"

        print(f"⏳ Загрузка модели «{model_name}» на {device} ({compute})…")
        _model_cache[model_name] = WhisperModel(
            model_name, device=device, compute_type=compute
        )
        print(f"✅ Модель «{model_name}» готова!")
    return _model_cache[model_name]


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def format_timestamp(seconds: float) -> str:
    """Convert seconds → HH:MM:SS,mmm (SRT style)."""
    td = datetime.timedelta(seconds=seconds)
    total_seconds = int(td.total_seconds())
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    secs = total_seconds % 60
    millis = int((seconds - int(seconds)) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


def format_timestamp_vtt(seconds: float) -> str:
    """Convert seconds → HH:MM:SS.mmm (VTT style)."""
    return format_timestamp(seconds).replace(",", ".")


def segments_to_plain(segments: list) -> str:
    return "\n".join(seg["text"].strip() for seg in segments)


def segments_to_timestamps(segments: list) -> str:
    lines = []
    for seg in segments:
        start = format_timestamp_vtt(seg["start"]).replace(",", ".")
        end = format_timestamp_vtt(seg["end"]).replace(",", ".")
        lines.append(f"[{start} → {end}]  {seg['text'].strip()}")
    return "\n".join(lines)


def segments_to_srt(segments: list) -> str:
    lines = []
    for i, seg in enumerate(segments, 1):
        lines.append(str(i))
        lines.append(f"{format_timestamp(seg['start'])} --> {format_timestamp(seg['end'])}")
        lines.append(seg["text"].strip())
        lines.append("")
    return "\n".join(lines)


def segments_to_vtt(segments: list) -> str:
    lines = ["WEBVTT", ""]
    for seg in segments:
        lines.append(f"{format_timestamp_vtt(seg['start'])} --> {format_timestamp_vtt(seg['end'])}")
        lines.append(seg["text"].strip())
        lines.append("")
    return "\n".join(lines)


def segments_to_json(segments: list) -> str:
    return json.dumps(segments, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# Core transcription
# ---------------------------------------------------------------------------

LANGUAGES = {
    "Автоопределение": None,
    "Русский": "ru",
    "English": "en",
    "Deutsch": "de",
    "Français": "fr",
    "Español": "es",
    "Italiano": "it",
    "Português": "pt",
    "中文": "zh",
    "日本語": "ja",
    "한국어": "ko",
    "العربية": "ar",
    "हिन्दी": "hi",
    "Türkçe": "tr",
    "Polski": "pl",
    "Nederlands": "nl",
    "Svenska": "sv",
    "Українська": "uk",
}

MODEL_INFO = {
    "tiny":             "~75 MB  · Самая быстрая, низкое качество",
    "base":             "~145 MB · Быстрая, приемлемое качество",
    "small":            "~490 MB · Хороший баланс скорости и качества",
    "medium":           "~1.5 GB · Высокое качество",
    "large-v3":         "~3.1 GB · Максимальное качество",
    "large-v3-turbo":   "~1.6 GB · Как large-v3, но быстрее (рекомендуется)",
    "distil-large-v3":  "~760 MB · Быстрый и качественный (только English)",
}


def transcribe(
    audio_path: str,
    model_name: str,
    language: str,
    task: str,
    progress=gr.Progress(track_tqdm=True),
):
    """Run transcription and return all output formats."""
    if not audio_path:
        raise gr.Error("⚠️ Загрузи аудио или видео файл!")

    lang_code = LANGUAGES.get(language)
    model = get_model(model_name)

    t0 = time.time()
    segments_gen, info = model.transcribe(
        audio_path,
        language=lang_code,
        task="translate" if task == "Перевести на English" else "transcribe",
        beam_size=5,
        vad_filter=True,
        vad_parameters=dict(min_silence_duration_ms=500),
    )

    segments = []
    for seg in segments_gen:
        segments.append({
            "start": seg.start,
            "end": seg.end,
            "text": seg.text,
        })

    elapsed = time.time() - t0
    duration = info.duration or 0
    detected = info.language or "?"
    speed_ratio = duration / elapsed if elapsed > 0 else 0

    stats = (
        f"🌐 Язык: {detected}  ·  "
        f"⏱ Длительность: {datetime.timedelta(seconds=int(duration))}  ·  "
        f"⚡ Обработка: {elapsed:.1f}с ({speed_ratio:.1f}× реалтайм)"
    )

    plain = segments_to_plain(segments)
    stamped = segments_to_timestamps(segments)
    srt = segments_to_srt(segments)
    vtt = segments_to_vtt(segments)
    js = segments_to_json(segments)

    return stats, plain, stamped, srt, vtt, js, segments


# ---------------------------------------------------------------------------
# File export
# ---------------------------------------------------------------------------

def export_file(segments_json: str, fmt: str):
    """Export transcription to a downloadable file."""
    if not segments_json:
        raise gr.Error("Сначала выполни транскрибацию!")

    segments = json.loads(segments_json)
    ext_map = {
        "TXT": ("txt", segments_to_plain),
        "SRT": ("srt", segments_to_srt),
        "VTT": ("vtt", segments_to_vtt),
        "JSON": ("json", segments_to_json),
        "TSV": ("tsv", lambda segs: "start\tend\ttext\n" + "\n".join(
            f"{s['start']:.3f}\t{s['end']:.3f}\t{s['text'].strip()}" for s in segs
        )),
    }

    ext, formatter = ext_map[fmt]
    content = formatter(segments)

    tmp = tempfile.NamedTemporaryFile(
        delete=False, suffix=f".{ext}", mode="w", encoding="utf-8"
    )
    tmp.write(content)
    tmp.close()
    return tmp.name


# ---------------------------------------------------------------------------
# Gradio UI
# ---------------------------------------------------------------------------

CUSTOM_CSS = """
/* ── Dark pro theme ─────────────────────────────────────── */
:root {
    --primary: #7c3aed;
    --primary-hover: #6d28d9;
}

.gradio-container {
    max-width: 960px !important;
    margin: 0 auto !important;
}

/* Header */
.app-header {
    text-align: center;
    padding: 2rem 0 1rem;
}
.app-header h1 {
    font-size: 2.4rem;
    font-weight: 800;
    background: linear-gradient(135deg, #7c3aed, #ec4899);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 0.25rem;
}
.app-header p {
    opacity: 0.7;
    font-size: 1rem;
}

/* Stats bar */
.stats-bar {
    font-size: 0.95rem;
    padding: 0.75rem 1rem;
    border-radius: 8px;
    margin-top: 0.5rem;
}

/* Export buttons */
.export-row button {
    min-width: 70px !important;
}

/* Tabs */
.tab-nav button {
    font-weight: 600 !important;
}
"""

def build_ui():
    with gr.Blocks(
        css=CUSTOM_CSS,
        title="WhisperApp",
        theme=gr.themes.Base(
            primary_hue="violet",
            neutral_hue="slate",
            font=[gr.themes.GoogleFont("IBM Plex Sans"), "system-ui", "sans-serif"],
        ),
    ) as app:

        # State to hold raw segments for export
        segments_state = gr.State("")

        # Header
        gr.HTML("""
        <div class="app-header">
            <h1>🎙️ WhisperApp</h1>
            <p>Бесплатная транскрибация · Все модели Whisper · Без ограничений</p>
        </div>
        """)

        # ── Controls ────────────────────────────────────
        with gr.Row():
            with gr.Column(scale=2):
                audio_input = gr.Audio(
                    label="Аудио / Видео",
                    type="filepath",
                    sources=["upload", "microphone"],
                )
            with gr.Column(scale=1):
                model_dd = gr.Dropdown(
                    choices=list(MODEL_INFO.keys()),
                    value="large-v3-turbo",
                    label="Модель",
                    info="large-v3-turbo — лучший баланс",
                )
                lang_dd = gr.Dropdown(
                    choices=list(LANGUAGES.keys()),
                    value="Автоопределение",
                    label="Язык",
                )
                task_dd = gr.Radio(
                    ["Транскрибация", "Перевести на English"],
                    value="Транскрибация",
                    label="Задача",
                )

        run_btn = gr.Button("🚀 Транскрибировать", variant="primary", size="lg")
        stats_box = gr.Markdown("", elem_classes=["stats-bar"])

        # ── Output tabs ─────────────────────────────────
        with gr.Tabs():
            with gr.Tab("📝 Текст"):
                txt_output = gr.Textbox(
                    label="Текст без таймкодов",
                    lines=16,
                    show_copy_button=True,
                    interactive=False,
                )
            with gr.Tab("⏱ Таймкоды"):
                stamped_output = gr.Textbox(
                    label="Текст с таймкодами",
                    lines=16,
                    show_copy_button=True,
                    interactive=False,
                )
            with gr.Tab("SRT"):
                srt_output = gr.Textbox(
                    label="Субтитры SRT",
                    lines=16,
                    show_copy_button=True,
                    interactive=False,
                )
            with gr.Tab("VTT"):
                vtt_output = gr.Textbox(
                    label="Субтитры WebVTT",
                    lines=16,
                    show_copy_button=True,
                    interactive=False,
                )
            with gr.Tab("JSON"):
                json_output = gr.Textbox(
                    label="JSON",
                    lines=16,
                    show_copy_button=True,
                    interactive=False,
                )

        # ── Export row ───────────────────────────────────
        gr.Markdown("### 💾 Скачать файл")
        with gr.Row(elem_classes=["export-row"]):
            for fmt in ["TXT", "SRT", "VTT", "JSON", "TSV"]:
                btn = gr.Button(f"⬇ {fmt}", size="sm")
                btn.click(
                    fn=export_file,
                    inputs=[segments_state, gr.State(fmt)],
                    outputs=gr.File(label=f"{fmt} файл"),
                )

        # ── Model info ──────────────────────────────────
        with gr.Accordion("ℹ️ Информация о моделях", open=False):
            info_md = "\n".join(
                f"- **{name}** — {desc}" for name, desc in MODEL_INFO.items()
            )
            gr.Markdown(info_md)

        # ── Wiring ──────────────────────────────────────

        def on_transcribe(audio, model, lang, task):
            stats, plain, stamped, srt, vtt, js, segments = transcribe(
                audio, model, lang, task
            )
            return stats, plain, stamped, srt, vtt, js, json.dumps(segments, ensure_ascii=False)

        run_btn.click(
            fn=on_transcribe,
            inputs=[audio_input, model_dd, lang_dd, task_dd],
            outputs=[stats_box, txt_output, stamped_output, srt_output, vtt_output, json_output, segments_state],
        )

    return app


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="WhisperApp — бесплатная транскрибация")
    parser.add_argument("--host", default="127.0.0.1", help="Host (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=7860, help="Port (default: 7860)")
    parser.add_argument("--share", action="store_true", help="Create public Gradio link")
    args = parser.parse_args()

    app = build_ui()
    app.launch(server_name=args.host, server_port=args.port, share=args.share)
