/* ============================================================
   Carlsbad A-Tech — Main JavaScript
   Minimal: menu, dropdowns, FAQ accordion, form validation
   ============================================================ */

(function () {
  "use strict";

  /* --- Mobile Menu Toggle --- */
  const hamburger = document.querySelector(".hamburger");
  const navMobile = document.querySelector(".nav-mobile");

  if (hamburger && navMobile) {
    hamburger.addEventListener("click", function () {
      hamburger.classList.toggle("hamburger--active");
      navMobile.classList.toggle("nav-mobile--open");
      document.body.style.overflow = navMobile.classList.contains(
        "nav-mobile--open",
      )
        ? "hidden"
        : "";
      hamburger.setAttribute(
        "aria-expanded",
        navMobile.classList.contains("nav-mobile--open"),
      );
    });
  }

  /* --- Mobile Sub-menu Toggles --- */
  document.querySelectorAll(".nav-mobile__toggle").forEach(function (toggle) {
    toggle.addEventListener("click", function () {
      var submenu = this.nextElementSibling;
      if (submenu && submenu.classList.contains("nav-mobile__sub")) {
        this.classList.toggle("nav-mobile__toggle--open");
        submenu.classList.toggle("nav-mobile__sub--open");
      }
    });
  });

  /* --- FAQ Accordion --- */
  document.querySelectorAll(".faq__question").forEach(function (question) {
    question.addEventListener("click", function () {
      var item = this.parentElement;
      var isOpen = item.classList.contains("faq__item--open");

      // Close all siblings
      item.parentElement
        .querySelectorAll(".faq__item--open")
        .forEach(function (openItem) {
          openItem.classList.remove("faq__item--open");
        });

      // Toggle current
      if (!isOpen) {
        item.classList.add("faq__item--open");
      }
    });
  });

  /* --- Form Validation --- */
  document.querySelectorAll(".form").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var isValid = true;

      // Clear previous errors
      form.querySelectorAll(".form__group--error").forEach(function (group) {
        group.classList.remove("form__group--error");
      });

      // Validate required fields
      form.querySelectorAll("[required]").forEach(function (field) {
        var group = field.closest(".form__group");
        if (!field.value.trim()) {
          isValid = false;
          if (group) group.classList.add("form__group--error");
        }
      });

      // Validate phone format (basic)
      var phoneField = form.querySelector('input[type="tel"]');
      if (phoneField && phoneField.value.trim()) {
        var phone = phoneField.value.replace(/[\s\-\(\)]/g, "");
        if (phone.length < 10 || !/^[\+]?[\d]{10,15}$/.test(phone)) {
          isValid = false;
          var group = phoneField.closest(".form__group");
          if (group) group.classList.add("form__group--error");
        }
      }

      if (isValid) {
        // Show success message
        var successMsg = document.createElement("div");
        successMsg.className = "form__success";
        successMsg.style.cssText =
          "background:#059669;color:#fff;padding:1rem;border-radius:8px;text-align:center;margin-top:1rem;";
        successMsg.textContent =
          "Thank you! We will contact you shortly to schedule your service.";
        form.appendChild(successMsg);
        form.reset();

        // Remove success message after 5 seconds
        setTimeout(function () {
          if (successMsg.parentNode) {
            successMsg.parentNode.removeChild(successMsg);
          }
        }, 5000);
      }
    });
  });

  /* --- Smooth Scroll for Anchor Links --- */
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener("click", function (e) {
      var targetId = this.getAttribute("href");
      if (targetId === "#") return;
      var target = document.querySelector(targetId);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: "smooth", block: "start" });

        // Close mobile menu if open
        if (navMobile && navMobile.classList.contains("nav-mobile--open")) {
          hamburger.classList.remove("hamburger--active");
          navMobile.classList.remove("nav-mobile--open");
          document.body.style.overflow = "";
        }
      }
    });
  });

  /* --- Close mobile menu on resize to desktop --- */
  var mql = window.matchMedia("(min-width: 768px)");
  function handleResize(e) {
    if (
      e.matches &&
      navMobile &&
      navMobile.classList.contains("nav-mobile--open")
    ) {
      hamburger.classList.remove("hamburger--active");
      navMobile.classList.remove("nav-mobile--open");
      document.body.style.overflow = "";
    }
  }
  if (mql.addEventListener) {
    mql.addEventListener("change", handleResize);
  }
})();
