# SEO Company — Skills Reference Guide

> **Роль**: AI-ассистент COO крупной SEO-компании
> **Дата создания**: 2026-02-19

---

## Карта скилов по отделам

### Навигация

| Отдел                                                             | Скилы                                                                                                        | Кол-во |
| ----------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ | ------ |
| [Стратегия и планирование](#1-отдел-стратегии-и-планирования)     | seo, seo-plan, seo-audit                                                                                     | 3      |
| [Исследование ключевых слов](#2-отдел-исследования-ключевых-слов) | keyword-research                                                                                             | 1      |
| [Контент](#3-отдел-контента)                                      | seo-content, seo-content-writer, seo-programmatic                                                            | 3      |
| [On-Page оптимизация](#4-отдел-on-page-оптимизации)               | seo-page, seo-schema, seo-images                                                                             | 3      |
| [Техническое SEO](#5-отдел-технического-seo)                      | seo-technical, technical-seo-checker, seo-sitemap, site-architecture, pagespeed-insights, accessibility-a11y | 6      |
| [Внутренняя оптимизация](#6-отдел-внутренней-оптимизации)         | internal-linking-optimizer, site-architecture                                                                | 2      |
| [Линкбилдинг](#7-отдел-линкбилдинга)                              | backlink-analyzer, skyscraper-technique                                                                      | 2      |
| [Конкурентный анализ](#8-отдел-конкурентного-анализа)             | seo-competitor-pages, competitor-teardown                                                                    | 2      |
| [Международное SEO](#9-отдел-международного-seo)                  | seo-hreflang                                                                                                 | 1      |
| [Локальное SEO](#10-отдел-локального-seo)                         | local-seo                                                                                                    | 1      |
| [eCommerce SEO](#11-отдел-ecommerce-seo)                          | ecommerce-seo-audit                                                                                          | 1      |
| [AI-поиск (GEO/AEO)](#12-отдел-ai-поиска-geoaeo)                  | seo-geo, geo-content-optimizer, ai-search-optimization                                                       | 3      |

**Итого**: 27 SEO-скилов

---

## 1. Отдел стратегии и планирования

### `seo` — Главный SEO-хаб

**Когда использовать**: Комплексный SEO-анализ любого сайта. Определяет тип бизнеса, делегирует задачи специализированным скилам.

**Триггеры**: `sео анализ`, `аудит сайта`, `проверь SEO`, `полный анализ`

**Что делает**:

- Автоопределение типа бизнеса (ecommerce, SaaS, local, media)
- Полный аудит сайта с делегацией 6 специалистам
- Генерация единого отчёта с приоритизированными рекомендациями

```
Пример: "Сделай полный SEO-анализ example.com"
```

---

### `seo-plan` — Стратегическое SEO-планирование

**Когда использовать**: Разработка SEO-стратегии и роадмапа для нового или существующего сайта.

**Триггеры**: `SEO стратегия`, `план продвижения`, `роадмап SEO`, `с чего начать SEO`

**Что делает**:

- Индустриальные шаблоны стратегий (SaaS, ecommerce, local, media)
- Конкурентный анализ с определением позиционирования
- Контент-стратегия с topic clusters
- Техническая дорожная карта
- Календарный план по месяцам/кварталам

```
Пример: "Составь SEO-стратегию для SaaS-компании в нише project management"
```

---

### `seo-audit` — Полный аудит сайта

**Когда использовать**: Комплексный аудит с параллельной делегацией задач 6 субагентам.

**Триггеры**: `полный аудит`, `SEO audit`, `проверь весь сайт`, `найди все проблемы`

**Что делает**:

- Кроулинг до 500 страниц
- Делегация 6 специалистам: техническое SEO, on-page, контент, ссылки, schema, скорость
- Единый отчёт с приоритизацией (critical / high / medium / low)

```
Пример: "Проведи полный SEO-аудит mystore.com"
```

---

## 2. Отдел исследования ключевых слов

### `keyword-research` — Исследование ключевых слов

**Когда использовать**: Поиск ключевых слов, определение search intent, планирование контента.

**Триггеры**: `найди ключевые`, `keyword research`, `о чём писать`, `какие запросы`, `topic ideas`, `семантика`

**Что делает**:

- Генерация seed-слов и их расширение (модификаторы, long-tail)
- Классификация intent (informational, navigational, commercial, transactional)
- Оценка сложности (1-100) и opportunity score
- Кластеризация по topic clusters (pillar + cluster articles)
- Определение GEO-возможностей (запросы, на которые отвечают AI)
- Контент-календарь

```
Пример: "Найди ключевые слова для сервиса email-маркетинга для малого бизнеса"
Пример: "Какие low-competition запросы с коммерческим intent в нише CRM?"
```

---

## 3. Отдел контента

### `seo-content` — Контентная оптимизация

**Когда использовать**: Анализ и оптимизация существующего контента на странице.

**Триггеры**: `оптимизируй контент`, `улучши текст`, `контент не ранжируется`

---

### `seo-content-writer` — SEO-копирайтинг

**Когда использовать**: Написание нового SEO-контента с нуля — статьи, лендинги, гайды.

**Триггеры**: `напиши статью`, `создай контент`, `блог пост`, `SEO текст`, `write article`, `draft content`

**Что делает**:

- CORE-EEAT качественные стандарты (80 пунктов)
- Keyword mapping (primary, secondary, LSI)
- Оптимизация title (до 60 символов) + meta description (150-160)
- Структура H1-H6 с keyword integration
- FAQ-секция для featured snippets
- Internal/external link recommendations
- SEO Score оценка готового контента

```
Пример: "Напиши SEO-статью на 2000 слов про email marketing best practices для малого бизнеса"
Пример: "Создай comparison article: Notion vs Asana vs Monday"
```

---

### `seo-programmatic` — Программатическое SEO

**Когда использовать**: Массовая генерация страниц по шаблонам (города, категории, продукты).

**Триггеры**: `programmatic SEO`, `массовая генерация`, `шаблонные страницы`, `страницы по городам`

```
Пример: "Создай шаблон для 500 страниц [услуга] в [город]"
```

---

## 4. Отдел On-Page оптимизации

### `seo-page` — Глубокий анализ одной страницы

**Когда использовать**: Детальный SEO-анализ конкретной страницы (title, meta, headings, content, schema, images, performance).

**Триггеры**: `проанализируй страницу`, `проверь URL`, `on-page анализ`, `почему страница не ранжируется`

```
Пример: "Проанализируй SEO страницы example.com/blog/seo-guide"
```

---

### `seo-schema` — Schema.org разметка

**Когда использовать**: Генерация, валидация и исправление структурированных данных (JSON-LD).

**Триггеры**: `schema markup`, `structured data`, `JSON-LD`, `rich snippets`, `разметка`

**Что делает**:

- Детектирование существующей разметки
- Генерация JSON-LD для: Organization, Article, Product, FAQ, HowTo, LocalBusiness, Breadcrumbs
- Валидация по спецификации Schema.org

```
Пример: "Сгенерируй schema markup для страницы продукта с reviews"
```

---

### `seo-images` — Оптимизация изображений

**Когда использовать**: Анализ и оптимизация изображений для SEO (alt, size, format, lazy loading).

**Триггеры**: `оптимизируй картинки`, `alt теги`, `image SEO`, `изображения медленные`

---

## 5. Отдел технического SEO

### `seo-technical` — Техническое SEO

**Когда использовать**: Проверка технических аспектов SEO (crawlability, indexability, robots.txt, canonical).

**Триггеры**: `техническое SEO`, `robots.txt`, `canonical`, `индексация`, `crawl budget`

---

### `technical-seo-checker` — Продвинутая техническая проверка

**Когда использовать**: Глубокий технический аудит: скорость, crawlability, indexability, mobile, security, structured data.

**Триггеры**: `technical audit`, `Core Web Vitals`, `сайт медленный`, `Google не индексирует`, `mobile issues`

**Что делает**:

- Page speed анализ (LCP, FID/INP, CLS)
- Crawlability (robots.txt, meta robots, canonical)
- Indexability (noindex, redirects, duplicate content)
- Mobile-friendliness
- Security (HTTPS, mixed content)
- Structured data validation

```
Пример: "Проверь техническое SEO для example.com — сайт просел в индексации"
```

---

### `seo-sitemap` — XML Sitemap

**Когда использовать**: Анализ, валидация или генерация XML-карт сайта.

**Триггеры**: `sitemap`, `карта сайта`, `sitemap.xml`, `sitemap validation`

**Что делает**:

- Валидация формата, URL, структуры
- Генерация новых sitemap с индустриальными шаблонами
- Проверка quality gates для location pages

---

### `site-architecture` — Архитектура сайта

**Когда использовать**: Настройка технического фундамента сайта — robots.txt, sitemap, meta tags, Core Web Vitals, AI-crawler конфигурация.

**Триггеры**: `архитектура сайта`, `robots.txt`, `структура сайта`, `AI crawlers`, `meta tags`, `Core Web Vitals`

**Что делает**:

- robots.txt шаблоны (включая AI-ботов: GPTBot, ClaudeBot, PerplexityBot)
- XML sitemap (статические + динамические для Next.js)
- Meta tags (basic, Open Graph, Twitter Cards)
- URL structure best practices
- Canonical URLs
- Security headers
- Core Web Vitals чеклисты (LCP < 2.5s, INP < 200ms, CLS < 0.1)
- Internal linking architecture
- Structured data placement
- Next.js-специфичные реализации

```
Пример: "Настрой архитектуру нового Next.js сайта: robots, sitemap, meta, CWV"
Пример: "Как разрешить AI-ботам кроулить мой сайт?"
```

---

### `pagespeed-insights` — PageSpeed аудит

**Когда использовать**: Аудит производительности по гайдлайнам Google PageSpeed Insights.

**Триггеры**: `page speed`, `Lighthouse`, `производительность`, `сайт медленный`, `Core Web Vitals`, `LCP`, `CLS`

**Что делает**:

- Анализ Lab data (Lighthouse) и Field data (CrUX)
- Core Web Vitals: FCP, LCP, CLS, INP, TTFB
- Детальные решения: images, render-blocking, fonts, caching, JS bundles
- Accessibility и SEO чеклисты
- Целевые метрики: 90+ по всем категориям

```
Пример: "Проведи PageSpeed аудит example.com — на мобильных score 35"
```

---

### `accessibility-a11y` — Доступность (WCAG)

**Когда использовать**: Проверка и улучшение веб-доступности по стандартам WCAG.

**Триггеры**: `accessibility`, `доступность`, `WCAG`, `a11y`, `screen reader`, `ARIA`

**Что делает**:

- Semantic HTML структура
- ARIA implementation
- Color contrast (4.5:1 для текста, 3:1 для крупного)
- Focus management
- Form accessibility
- Keyboard navigation

```
Пример: "Проверь accessibility нашего лендинга — нужен WCAG AA compliance"
```

---

## 6. Отдел внутренней оптимизации

### `internal-linking-optimizer` — Внутренняя перелинковка

**Когда использовать**: Анализ и оптимизация внутренних ссылок, обнаружение orphan pages, распределение link equity.

**Триггеры**: `внутренние ссылки`, `перелинковка`, `orphan pages`, `site architecture`, `link equity`, `сиротские страницы`

**Что делает**:

- Анализ текущей структуры внутренних ссылок
- Обнаружение orphan pages (страниц без ссылок)
- Anchor text анализ и оптимизация
- Topic cluster link strategy (pillar ← → cluster)
- Контекстуальные link opportunities
- Навигация и footer оптимизация
- Link equity flow model
- Фазовый план реализации (Phase 1-3)

**Модели архитектуры**: Hub-and-Spoke, Silo, Flat, Pyramid, Mesh

```
Пример: "Найди orphan pages и создай стратегию внутренней перелинковки для блога"
Пример: "Оптимизируй anchor text для страниц в topic cluster про email marketing"
```

---

## 7. Отдел линкбилдинга

### `backlink-analyzer` — Анализ бэклинков

**Когда использовать**: Анализ ссылочного профиля, поиск toxic links, конкурентный анализ ссылок, возможности для линкбилдинга.

**Триггеры**: `анализ бэклинков`, `ссылочный профиль`, `toxic links`, `link building`, `disavow`, `кто ссылается`

**Что делает**:

- Profile Overview: total backlinks, referring domains, DA/DR, dofollow/nofollow ratio
- Link Velocity (30/90/365 дней)
- Authority Distribution (DA 0-19 ... DA 80-100)
- Link Quality Assessment (5-факторная матрица)
- Toxic Link Detection + Disavow рекомендации
- Competitive Backlink Analysis (вы vs конкуренты)
- Link Intersection Analysis (сайты, ссылающиеся на конкурентов, но не на вас)
- Link Building Opportunities (broken links, unlinked mentions, resource pages, guest posts)
- Outreach email frameworks + response rate benchmarks

**CITE Item Mapping**: Данные напрямую питают domain-authority-auditor (C01-C10, T01-T05)

```
Пример: "Проанализируй ссылочный профиль example.com vs hubspot.com vs mailchimp.com"
Пример: "Найди toxic backlinks для нашего домена и подготовь disavow файл"
```

---

### `skyscraper-technique` — Техника небоскрёба

**Когда использовать**: Построение ссылок через 3-шаговую методику Brian Dean: найти контент с ссылками, сделать в 10x лучше, аутрич.

**Триггеры**: `skyscraper`, `техника небоскрёба`, `outreach`, `linkable assets`, `Brian Dean`

**Что делает**:

1. **Find**: Поиск контента с 50-100+ referring domains
2. **Create**: План 10x улучшения (comprehensive, current, design, depth, originality)
3. **Outreach**: Шаблоны писем, prospect list cleaning, tracking

- Selection criteria (referring domains, topic relevance, improvement potential)
- Outreach benchmarks (open rate 30%+, reply 10%+, link rate 5%+)
- Campaign tracking templates

```
Пример: "Найди skyscraper opportunities в нише project management — контент с 100+ ссылками"
Пример: "Помоги составить outreach email для нашего улучшенного гайда по email marketing"
```

---

## 8. Отдел конкурентного анализа

### `seo-competitor-pages` — Страницы сравнения

**Когда использовать**: Создание страниц "X vs Y", "alternatives to X", feature matrices.

**Триггеры**: `X vs Y`, `альтернативы`, `сравнение`, `competitor pages`, `feature matrix`

**Что делает**:

- "X vs Y" layouts с feature comparison
- "Alternatives to X" pages
- Feature matrices с schema markup
- Conversion-optimized structure

```
Пример: "Создай страницу сравнения: Notion vs Asana vs Monday.com"
Пример: "Сделай лендинг 'Top 10 Alternatives to Salesforce'"
```

---

### `competitor-teardown` — Конкурентная разведка

**Когда использовать**: Глубокий 7-уровневый анализ конкурента: продукт, цены, позиционирование, тракшн, отзывы, контент, команда.

**Триггеры**: `competitor analysis`, `конкурентный анализ`, `разбор конкурента`, `SWOT`, `market research`

**Что делает**:

- **7-Layer Analysis**: Product, Pricing, Positioning, Traction, Reviews, Content, Team
- Feature Matrix (с символами и условиями)
- Pricing Comparison (hidden costs, min seats, lock-in)
- SWOT Analysis для каждого конкурента
- Positioning Map (2x2 матрица)
- Review Mining (G2, Capterra, Reddit, Product Hunt)
- Executive Summary + Detailed Report

```
Пример: "Сделай competitor teardown для Ahrefs, SEMrush и Moz"
```

---

## 9. Отдел международного SEO

### `seo-hreflang` — Hreflang и международное SEO

**Когда использовать**: Аудит, валидация и генерация hreflang тегов. Международная SEO-оптимизация.

**Триггеры**: `hreflang`, `международное SEO`, `мультиязычный сайт`, `language tags`

**Что делает**:

- Обнаружение типичных ошибок hreflang
- Валидация language/region codes
- Генерация корректных hreflang тегов
- Аудит международной SEO-структуры

```
Пример: "Проверь hreflang для сайта с 5 языковыми версиями"
```

---

## 10. Отдел локального SEO

### `local-seo` — Локальное SEO

**Когда использовать**: Оптимизация для локального поиска — NAP consistency, Google Business Profile, local keywords, local schema.

**Триггеры**: `local SEO`, `локальное SEO`, `Google Business`, `NAP`, `[город] + [услуга]`

**Что делает**:

- Автоопределение локального бизнеса
- NAP (Name, Address, Phone) consistency check
- Генерация local keywords: "[город] + [услуга]"
- Google Business Profile оптимизация
- LocalBusiness Schema генерация
- Стратегия отзывов

```
Пример: "Оптимизируй локальное SEO для стоматологии в Киеве"
```

---

## 11. Отдел eCommerce SEO

### `ecommerce-seo-audit` — eCommerce SEO аудит

**Когда использовать**: SEO-аудит интернет-магазина — product pages, collection pages, crawl analysis, competitor research.

**Триггеры**: `ecommerce SEO`, `SEO магазина`, `product page SEO`, `collection pages`, `Shopify SEO`

**Что делает**:

- Product page audit (title, description, schema, images, reviews)
- Collection/category page optimization
- Technical crawl analysis (log files, sitemap, redirect chains)
- Internal link audit
- Competitor product page comparison (top 5 по keyword)

**Требует данных**: Crawl export (Screaming Frog/Sitebulb), server logs, analytics data

```
Пример: "Аудит product pages для myshop.com — конверсия из органики упала"
```

---

## 12. Отдел AI-поиска (GEO/AEO)

### `seo-geo` — Generative Engine Optimization (встроенный)

**Когда использовать**: Оптимизация под AI Overviews, ChatGPT, Perplexity и другие AI-поисковики.

**Триггеры**: `GEO`, `AI Overviews`, `ChatGPT search`, `Perplexity`, `AI-оптимизация`

---

### `geo-content-optimizer` — GEO контент-оптимизация

**Когда использовать**: Сделать контент цитируемым AI-системами (ChatGPT, Claude, Perplexity, Google AI Overviews).

**Триггеры**: `optimize for AI`, `get cited by ChatGPT`, `AI citations`, `AI-friendly content`, `LLM visibility`

**Что делает**:

- **CORE-EEAT GEO-First Targets** (top 6 priority items):
  1. Direct Answer в первых 150 словах
  2. Structured FAQ with Schema
  3. Data in tables, not prose
  4. JSON-LD Schema Markup
  5. Original first-party data
  6. Key Takeaways / Summary Box
- Quotable statement creation (statistics, facts, definitions, comparisons)
- Authority signals (expert quotes, source citations)
- Structure optimization (Q&A, comparison tables, numbered lists)
- Factual density enhancement
- FAQ Schema implementation
- GEO Score (before/after)

**AI Engine Preferences**:
| Engine | Приоритетные элементы |
|--------|----------------------|
| Google AI Overview | Direct answer, Tables, Schema, FAQ |
| ChatGPT Browse | Direct answer, Data precision, Citations, Original data |
| Perplexity AI | Original data, Source freshness, External refs, Expertise |
| Claude | Evidence-claim mapping, Reasoning transparency, Limitations, Refs |

```
Пример: "Оптимизируй эту статью чтобы ChatGPT и Perplexity её цитировали"
Пример: "Аудит GEO-готовности контента на example.com/blog/seo-guide"
```

---

### `ai-search-optimization` — AEO & GEO стратегия

**Когда использовать**: Стратегический подход к видимости в AI-поиске. AEO (Answer Engine Optimization) + GEO (Generative Engine Optimization).

**Триггеры**: `AEO`, `answer engine`, `AI search strategy`, `generative search`, `zero-click`

**Что делает**:

- Понимание AEO vs GEO vs traditional SEO
- Ландшафт AI-поиска 2025-2026 (Google AI Overviews 2B+ users, 60% zero-click)
- Semantic HTML structure для AI readability
- Content structuring для AI-цитирования
- Platform-specific optimization (Google AIO, ChatGPT, Perplexity, Copilot)

```
Пример: "Разработай стратегию присутствия бренда в AI-поиске на 2026"
```

---

## Рабочие процессы (Workflows)

### Новый проект — полный цикл

```
1. seo-plan          → стратегия и роадмап
2. keyword-research  → семантическое ядро
3. site-architecture → технический фундамент
4. seo-content-writer → контент по плану
5. seo-schema        → structured data
6. internal-linking-optimizer → перелинковка
7. geo-content-optimizer → GEO-оптимизация
8. seo-audit         → финальная проверка
```

### Диагностика падения трафика

```
1. seo-audit         → найти все проблемы
2. technical-seo-checker → техническая проверка
3. seo-page          → анализ пострадавших страниц
4. backlink-analyzer → проверка ссылочного профиля
5. keyword-research  → поиск новых возможностей
```

### Выход на новый рынок

```
1. competitor-teardown → анализ конкурентов
2. keyword-research   → ключевые слова для рынка
3. seo-competitor-pages → страницы сравнения
4. seo-hreflang       → мультиязычная настройка (если нужно)
5. local-seo          → локальная оптимизация (если нужно)
```

### Контентная кампания

```
1. keyword-research      → семантика
2. seo-content-writer    → написание
3. geo-content-optimizer → GEO-оптимизация
4. seo-schema            → schema markup
5. internal-linking-optimizer → перелинковка
6. backlink-analyzer     → мониторинг линков
7. skyscraper-technique  → линкбилдинг
```

### eCommerce оптимизация

```
1. ecommerce-seo-audit → полный аудит магазина
2. seo-page           → анализ product/collection pages
3. seo-schema         → Product, Review schema
4. pagespeed-insights  → скорость загрузки
5. internal-linking-optimizer → перелинковка каталога
```

---

## Быстрый поиск скила по задаче

| Задача                        | Скил                         |
| ----------------------------- | ---------------------------- |
| Полный аудит сайта            | `seo-audit`                  |
| Анализ одной страницы         | `seo-page`                   |
| SEO стратегия с нуля          | `seo-plan`                   |
| Найти ключевые слова          | `keyword-research`           |
| Написать SEO-статью           | `seo-content-writer`         |
| Массовая генерация страниц    | `seo-programmatic`           |
| Schema markup                 | `seo-schema`                 |
| Оптимизация изображений       | `seo-images`                 |
| XML sitemap                   | `seo-sitemap`                |
| robots.txt / meta tags / CWV  | `site-architecture`          |
| Техническое SEO               | `technical-seo-checker`      |
| PageSpeed / Lighthouse        | `pagespeed-insights`         |
| Accessibility / WCAG          | `accessibility-a11y`         |
| Внутренние ссылки             | `internal-linking-optimizer` |
| Анализ бэклинков              | `backlink-analyzer`          |
| Линкбилдинг через контент     | `skyscraper-technique`       |
| X vs Y страницы               | `seo-competitor-pages`       |
| Разбор конкурента             | `competitor-teardown`        |
| Hreflang / i18n               | `seo-hreflang`               |
| Локальное SEO                 | `local-seo`                  |
| eCommerce SEO                 | `ecommerce-seo-audit`        |
| AI Overviews / GEO            | `seo-geo`                    |
| Сделать контент цитируемым AI | `geo-content-optimizer`      |
| AEO/GEO стратегия             | `ai-search-optimization`     |
| Контент оптимизация           | `seo-content`                |
