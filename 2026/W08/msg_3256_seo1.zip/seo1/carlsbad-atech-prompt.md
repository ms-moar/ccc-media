PROMPT — Создание сайта Carlsbad A-Tech | Appliance Repair San Diego Area

## Задача

Создать многостраничный сайт (HTML + CSS) для компании по ремонту бытовой техники **Carlsbad A-Tech**, оказывающей услуги в San Diego, California, USA.

Сайт: **28 страниц**, только английская версия. Фокус — локальное SEO, E-E-A-T сигналы, конверсия.

---

## Гео-стратегия и SEO-приоритеты

### Главная страница

Оптимизируется под гео — **San Diego, CA**:

- Главный ключ: **Appliance Repair San Diego — Carlsbad A-Tech**
- Бренд компании: **Carlsbad A-Tech**
- Подзаголовки и упоминания: сервисная зона охватывает San Diego County
- Список обслуживаемых районов (Clairemont, Hillcrest, La Jolla, Little Italy, Mira Mesa, Mission Valley, North Park, Ocean Beach, Pacific Beach, Point Loma, Rancho Bernardo, San Diego Downtown и др.) — упоминание в тексте и в блоке "Service Areas", **без отдельных страниц**

### Страницы услуг

SEO-ключ формата: **[Service] Repair Service in San Diego**

### Страницы брендов

SEO-ключ формата: **[Brand] Appliance Repair in San Diego**

---

## Структура сайта (28 страниц)

### Основные страницы (верхний уровень)

- Home
- Services (хаб + 10 дочерних)
- Brands (хаб + 14 дочерних)
- Contact

### Раздел Services (Услуги)

Страницы категорий ремонта:

1. Refrigerator Repair
2. Washer Repair
3. Dryer Repair
4. Oven Repair
5. Stove Repair
6. Kitchen Range Repair
7. Dishwasher Repair
8. Microwave Repair
9. Freezer Repair
10. Ice Maker Repair

**Требования к страницам услуг:**

- Географический фокус: **San Diego, CA** (с упоминанием Carlsbad как штаб-квартиры)
- SEO-ключ: `[Service] Repair Service in San Diego`
- Обязательное упоминание брендов (Sub-Zero, Viking, Bosch, Miele и др.)
- Акцент на выездной ремонт на дому по всему San Diego County

### Раздел Brands (Бренды)

Страницы брендов:

1. Sub Zero
2. Dacor
3. Viking
4. Thermador
5. Gaggenau
6. Bosch
7. Miele
8. Wolf
9. KitchenAid
10. Jenn Air
11. LG
12. Maytag
13. Samsung
14. GE

**Требования к страницам брендов:**

- SEO-ключ: `[Brand] Appliance Repair in San Diego`
- Обязательное упоминание категорий ремонта (refrigerator, oven, dishwasher, ice maker и т.д.)
- Подчёркивание опыта ремонта техники этого бренда

---

## Главная страница (Home)

Оптимизируется под **San Diego, CA** и должна включать:

- **Hero-блок** с акцентом на San Diego, CA и San Diego County
- **О компании**: локальный сервис, быстрый выезд, надёжность, лицензии, страховка, опыт работы
- **Блок категорий ремонта** (кликабельные карточки → страницы услуг)
- **Блок брендов** (кликабельные карточки → страницы брендов)
- **Service Areas** — текстовый блок со списком обслуживаемых районов San Diego (без отдельных страниц)
- **CTA-кнопки** (форма: Name + Phone + Service Type)
- **FAQ-блок**: 4–8 вопросов
- **2 тематических изображения** с SEO alt-тегами
- Микроразметка: **FAQPage**, **LocalBusiness**

---

## Страница Contact

- Чёткое указание зоны обслуживания: **San Diego County, CA**
- Форма обратной связи (Name, Phone, Service Type, Message)
- Часы работы
- **Google Maps embed** с зоной обслуживания
- CTA-кнопка: `Request Service in San Diego`
- Краткий FAQ по записи на ремонт
- Микроразметка: **LocalBusiness** с полным NAP (Name, Address, Phone)

---

## Навигация

На всех страницах — горизонтальное верхнее меню:

- Home
- Services (dropdown со всеми услугами)
- Brands (dropdown со всеми брендами)
- Contact

Мобильная версия: hamburger-меню.

---

## Обязательные требования ко ВСЕМ страницам

### SEO on-page

- `<title>` — уникальный для каждой страницы (до 60 символов)
- `<meta description>` — уникальный для каждой страницы (до 155 символов)
- `<link rel="canonical">` — на каждой странице
- H1 (1 шт.) + H2 (3–5 шт.) + H3 (по необходимости)
- Open Graph теги (og:title, og:description, og:image, og:url)

### Взаимные упоминания и перелинковка

- Страницы услуг → упоминают и ссылаются на бренды
- Страницы брендов → упоминают и ссылаются на услуги
- Breadcrumbs на всех дочерних страницах

### FAQ

- От 4 до 8 вопросов
- Тематика соответствует странице
- С микроразметкой **FAQPage** (JSON-LD)

### CTA

- Кнопка: `Request Service in San Diego`
- Форма: Name + Phone + Service Type

### Изображения

- 2 изображения на каждую страницу
- SEO-оптимизированные alt-теги (включают ключевой запрос страницы)
- Формат alt: `[Service/Brand] Repair in San Diego — Carlsbad A-Tech`
- Lazy loading (`loading="lazy"`)
- WebP формат с fallback

### Микроразметка (JSON-LD)

Каждая страница содержит:

- **FAQPage** — для FAQ-блока
- **LocalBusiness** — на Home и Contact (полный NAP, serviceArea, geo)
- **BreadcrumbList** — на всех дочерних страницах
- **Service** — на страницах услуг (serviceType, areaServed, provider)

> ⚠️ **Review / AggregateRating** — НЕ использовать. Google пенализирует self-served reviews. Отзывы собирать через Google Business Profile.

---

## Техническое SEO

### Обязательные файлы

- `sitemap.xml` — все 28 страниц, lastmod, priority
- `robots.txt` — разрешение индексации, ссылка на sitemap
- `favicon.ico` + `apple-touch-icon`

### Производительность (Core Web Vitals)

- **LCP** < 2.5s: оптимизация изображений (WebP, srcset), критический CSS inline
- **CLS** < 0.1: заданные размеры для изображений (width/height), font-display: swap
- **INP** < 200ms: минимальный JavaScript, defer/async для скриптов
- Минификация CSS
- Gzip/Brotli сжатие (через .htaccess или server config)

### Mobile-first

- Responsive design (mobile-first подход)
- Viewport meta tag
- Tap targets минимум 48×48px
- Читабельный размер шрифта без zoom (16px+ base)

### Семантический HTML

- `<header>`, `<nav>`, `<main>`, `<article>`, `<section>`, `<footer>`
- `<nav>` для breadcrumbs и меню
- `aria-label` для навигационных элементов

---

## Объём контента

| Тип страницы    | Объём (символов без пробелов) |
| --------------- | ----------------------------- |
| Главная (Home)  | 6 000 – 8 000                 |
| Страница услуги | 5 000 – 8 000                 |
| Страница бренда | 5 000 – 8 000                 |
| Contact         | 2 000 – 3 000                 |

---

## Ограничения по терминологии

| ❌ Запрещено       | ✅ Разрешено           |
| ------------------ | ---------------------- |
| authorized         | certified technician   |
| authorized service | trained technician     |
| authorized repair  | experienced technician |

---

## E-E-A-T сигналы (обязательно на сайте)

- **Experience**: упоминание конкретного опыта работы (количество лет, кол-во ремонтов)
- **Expertise**: описание квалификации техников, сертификатов, специализации по брендам
- **Authoritativeness**: упоминание лицензий, страховки, принадлежности к ассоциациям
- **Trustworthiness**: реальный адрес, телефон, часы работы, Google Maps, privacy policy

На каждой странице в footer:

- Полные контактные данные (NAP)
- Лицензия / страховка
- Ссылка на Google Business Profile

---

## Файловая структура

```
/carlsbad-a-tech-site
  index.html              ← Home (SEO: San Diego)
  contact.html
  services/
    index.html            ← Services Hub
    refrigerator-repair.html
    washer-repair.html
    dryer-repair.html
    oven-repair.html
    stove-repair.html
    kitchen-range-repair.html
    dishwasher-repair.html
    microwave-repair.html
    freezer-repair.html
    ice-maker-repair.html
  brands/
    index.html            ← Brands Hub
    sub-zero.html
    dacor.html
    viking.html
    thermador.html
    gaggenau.html
    bosch.html
    miele.html
    wolf.html
    kitchenaid.html
    jenn-air.html
    lg.html
    maytag.html
    samsung.html
    ge.html
  assets/
    css/
      main.css
      responsive.css
    img/
      [SEO-оптимизированные имена файлов, WebP формат]
    js/
      main.js             ← минимальный: меню, формы, lazy load
  sitemap.xml
  robots.txt
  favicon.ico
```

---

## Итоговый масштаб сайта

| Раздел                  | Кол-во страниц |
| ----------------------- | -------------- |
| Home                    | 1              |
| Services Hub + 10 услуг | 11             |
| Brands Hub + 14 брендов | 15             |
| Contact                 | 1              |
| **ИТОГО**               | **28**         |

---

## SEO-стратегия

### Иерархия ключевых запросов

```
[Уровень 1 — Главная]
  Appliance Repair San Diego — Carlsbad A-Tech

[Уровень 2 — Услуги]
  Refrigerator Repair Service in San Diego
  Washer Repair Service in San Diego
  ...и т.д.

[Уровень 2 — Бренды]
  Sub Zero Appliance Repair in San Diego
  Bosch Appliance Repair in San Diego
  ...и т.д.
```

### Внутренняя перелинковка

- Главная → Services Hub, Brands Hub, Contact
- Services Hub → все 10 услуг
- Brands Hub → все 14 брендов
- Страница услуги → 3–4 релевантных бренда
- Страница бренда → 3–4 релевантных услуги
- Все страницы → Home (через breadcrumbs и лого)

---

## Итог

Сайт должен быть:

- **28 страниц**, только EN
- Главная оптимизирована под **San Diego, CA**
- Районы San Diego упомянуты в контенте как зона обслуживания (без отдельных страниц)
- SEO-ориентированным с E-E-A-T сигналами и техническим SEO
- Логически связанным: услуги ↔ бренды
- С чистой семантической разметкой и Core Web Vitals оптимизацией
- Готовым к продвижению через Google Business Profile + органику
