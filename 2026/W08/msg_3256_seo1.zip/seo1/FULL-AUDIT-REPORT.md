# Full SEO Audit Report — seo1.moar.tools

**Business**: Carlsbad A-Tech — Appliance Repair San Diego
**Audit Date**: 2026-02-19
**Auditor**: SEO Audit Skill
**Pages Crawled**: 28 (full site)

---

## Executive Summary

### Overall SEO Health Score: **74 / 100**

**Business Type Detected**: Local Service Business (Appliance Repair, San Diego County)
**Site Architecture**: Static HTML, nginx/1.24.0, 28 pages across homepage + services (10) + brands (15) + contact (1) + hub pages (2)

### Top 5 Critical Issues

1. **No og:image on homepage** — The highest-traffic page has no Open Graph image, severely limiting social sharing and AI snippet appearance
2. **Twitter Card missing on homepage and most pages** — Only services/ hub has Twitter Card; all other pages are missing it
3. **Contact nav link on homepage goes to #contact anchor, not contact.html** — The dedicated contact page is an orphan from the homepage perspective; it has no incoming link from homepage nav or footer
4. **No AggregateRating schema on any service or brand page** — No star ratings in search results despite services with 50K+ repairs completed; major rich snippet opportunity missed
5. **No blog or content hub** — Zero content marketing presence, no ability to rank for informational queries or build topical authority

### Top 5 Quick Wins

1. Add og:image (800×600 or 1200×630 webp) to all pages without it (homepage, contact, refrigerator-repair, brands pages)
2. Add Twitter Card meta tags to homepage and all service/brand pages (copy pattern from services/ page)
3. Add AggregateRating schema to service pages (JSON-LD with ratingValue, reviewCount)
4. Add link to contact.html from homepage footer (currently linked only via #contact anchor)
5. Add `<link rel="preload" as="image" href="assets/img/home-1.webp">` to homepage for LCP optimization

---

## Technical SEO

### Score: 84 / 100

#### Crawlability

| Check                          | Status | Notes                                                                               |
| ------------------------------ | ------ | ----------------------------------------------------------------------------------- |
| robots.txt                     | PASS   | Properly configured, allows all bots including GPTBot, ClaudeBot, PerplexityBot     |
| sitemap.xml                    | PASS   | Valid XML, 28 URLs, all return HTTP 200                                             |
| Sitemap declared in robots.txt | PASS   | `Sitemap: https://seo1.moar.tools/sitemap.xml`                                      |
| HTTPS enforcement              | PASS   | HTTP 301 → HTTPS redirect working                                                   |
| Canonical tags                 | PASS   | All pages have self-referencing canonicals                                          |
| noindex tags                   | PASS   | No pages incorrectly set to noindex                                                 |
| Trailing slash redirects       | PASS   | `/services` → `/services/` (301, correct)                                           |
| 404 page                       | ISSUE  | Returns nginx default 404 (no custom branded 404 page)                              |
| www redirect                   | ISSUE  | `www.seo1.moar.tools` returns connection error — no www→non-www redirect configured |

#### Indexability

- All 28 sitemap pages return HTTP 200
- No redirect chains detected
- All canonical URLs match their own page URLs
- Sitemap `<lastmod>` is 2026-02-19 for all pages (consistent, good)
- `<changefreq>monthly</changefreq>` used across all pages (appropriate for a service site)

#### Security Headers

| Header                           | Status                                                        |
| -------------------------------- | ------------------------------------------------------------- |
| x-content-type-options           | PRESENT (nosniff)                                             |
| x-frame-options                  | PRESENT (SAMEORIGIN)                                          |
| x-xss-protection                 | PRESENT (1; mode=block) — note: deprecated in modern browsers |
| referrer-policy                  | PRESENT (strict-origin-when-cross-origin)                     |
| Strict-Transport-Security (HSTS) | **MISSING**                                                   |
| Content-Security-Policy          | **MISSING**                                                   |
| Permissions-Policy               | **MISSING**                                                   |

**Priority**: Add HSTS header (at minimum): `Strict-Transport-Security: max-age=31536000; includeSubDomains`

#### Core Web Vitals (estimated from static analysis)

| Metric | Estimated | Target  | Notes                                                                   |
| ------ | --------- | ------- | ----------------------------------------------------------------------- |
| LCP    | ~1.8s     | < 2.5s  | PASS — Single hero image (8 KB webp), CSS < 30 KB total, no blocking JS |
| INP    | N/A       | < 200ms | JS (main.js, 2.9 KB defer) is minimal — very low risk                   |
| CLS    | ~0.05     | < 0.1   | PASS — Image dimensions not explicitly set in HTML attributes           |
| TTFB   | 29ms      | < 800ms | EXCELLENT — Server responds in under 30ms                               |
| FCP    | ~0.3s     | < 1.8s  | PASS — Minimal render-blocking resources                                |

**Total page weight (homepage)**: ~108 KB (68KB HTML + 26KB CSS + 3KB JS + 8KB image)

#### Performance Opportunities

1. **No `<link rel="preload">` hints** — hero image (home-1.webp) should be preloaded: `<link rel="preload" as="image" href="assets/img/home-1.webp">`
2. **No DNS prefetch/preconnect** — negligible impact since no third-party resources
3. **Two separate CSS files** — main.css (26 KB) + responsive.css (3 KB) could be concatenated to save one HTTP request
4. **System font stack used** — no Google Fonts loading penalty; this is optimal
5. **Image lazy loading** — only 1 image exists above-fold; `loading="lazy"` is appropriately applied

---

## On-Page SEO

### Score: 78 / 100

#### Title Tags

| Page                | Title                                                    | Length | Assessment                                           |
| ------------------- | -------------------------------------------------------- | ------ | ---------------------------------------------------- |
| Homepage            | Appliance Repair San Diego \| Carlsbad A-Tech Same-Day   | 53     | GOOD                                                 |
| Contact             | Contact Us \| Carlsbad A-Tech Appliance Repair San Diego | 55     | GOOD                                                 |
| Services hub        | Appliance Repair Services San Diego \| Carlsbad A-Tech   | 53     | GOOD                                                 |
| Refrigerator Repair | Refrigerator Repair San Diego \| Carlsbad A-Tech         | 47     | GOOD                                                 |
| Washer Repair       | Washer Repair San Diego \| Carlsbad A-Tech               | 41     | SHORT — could add "Same-Day" or brand differentiator |
| Brands hub          | Appliance Brands We Service \| Carlsbad A-Tech San Diego | 55     | GOOD                                                 |
| Sub-Zero            | Sub-Zero Repair San Diego \| Carlsbad A-Tech             | 43     | SHORT — "Certified" or "Specialist" could strengthen |

All title tags are within the 50-60 character optimal range. All include the city (San Diego) and the brand name.

#### Meta Descriptions

| Page                | Length    | Assessment                                         |
| ------------------- | --------- | -------------------------------------------------- |
| Homepage            | 149 chars | GOOD — includes keyword, USP, phone number         |
| Contact             | 127 chars | GOOD                                               |
| Services hub        | 148 chars | GOOD                                               |
| Refrigerator Repair | 136 chars | GOOD                                               |
| Washer Repair       | 117 chars | SHORT — can add call-to-action or warranty mention |
| Brands hub          | 142 chars | GOOD                                               |
| Sub-Zero            | 135 chars | GOOD                                               |

#### Heading Structure

All audited pages have exactly 1 H1 tag — correct. H1s are unique and keyword-targeted.

| Page                | H1                                       |
| ------------------- | ---------------------------------------- |
| Homepage            | Expert Appliance Repair in San Diego     |
| Refrigerator Repair | Refrigerator Repair Service in San Diego |
| Washer Repair       | Washer Repair Service in San Diego       |
| Sub-Zero            | Sub-Zero Appliance Repair in San Diego   |

**H2/H3 structure**: Well-organized. Homepage has 6 H2s (logical sections), 30 H3s (individual services/brands/features).

**Issue**: H3 tags on homepage directly wrap `<a>` anchor tags for service cards — semantically acceptable, but the heading text starts with the anchor element rather than plain text. Acceptable but unusual.

#### Navigation Issues (HIGH)

- The homepage **"Contact"** nav item uses `href="#contact"` — it scrolls to an in-page CTA form, NOT the dedicated `/contact.html` page
- `/contact.html` has no incoming link from homepage (nav or footer) — it's effectively unreachable from the homepage
- The homepage nav **"Services"** dropdown links directly to individual service pages but does NOT link to the `/services/` hub page
- The homepage footer does NOT link to `/services/` hub or `/brands/` hub pages
- **No link to sitemap.xml anywhere** on the site (a minor best practice)

Service pages (e.g., refrigerator-repair.html) DO correctly link to `../contact.html` in their navigation and back to `../services/` hub — this is correct behavior on inner pages.

#### URL Structure

All URLs follow best practices:

- Lowercase, hyphenated slugs
- Descriptive and keyword-rich
- Logical hierarchy: `/services/[service-name].html`, `/brands/[brand-name].html`
- No URL parameters, no session IDs
- `.html` extension is consistent (acceptable, though extensionless is preferred for futureproofing)

---

## Content Quality

### Score: 72 / 100

#### E-E-A-T Assessment

| Signal                                  | Present | Notes                                                  |
| --------------------------------------- | ------- | ------------------------------------------------------ |
| Experience (15+ years stated)           | YES     | "15+ years experience" in meta, content, and stats     |
| Expertise (certifications mentioned)    | YES     | "Certified technicians", "manufacturer certifications" |
| Authoritativeness (third-party signals) | WEAK    | No Yelp/Google reviews displayed, no awards cited      |
| Trustworthiness (license, insurance)    | YES     | "Licensed, bonded, insured in California" mentioned    |
| Physical address                        | YES     | 2855 Carlsbad Blvd Suite 100, Carlsbad, CA 92008       |
| Phone number                            | YES     | (760) 555-0147 prominent in nav                        |

**Missing E-E-A-T signals**:

- No customer testimonials or reviews on any page
- No "About Us" page
- No team/technician profiles
- No awards, certifications with verifiable links (BBB, manufacturer partner badges)
- No case studies or before/after repair stories

#### Word Count Assessment

| Page                | Words | Assessment                                                 |
| ------------------- | ----- | ---------------------------------------------------------- |
| Homepage            | 1,797 | ACCEPTABLE for a local service homepage                    |
| Services hub        | 1,260 | THIN — hub pages benefit from more content (2,000+ target) |
| Refrigerator Repair | 1,992 | GOOD                                                       |
| Washer Repair       | 2,143 | GOOD                                                       |
| Dryer Repair        | 2,221 | GOOD                                                       |
| Oven Repair         | 2,255 | GOOD                                                       |
| Brands hub          | 1,436 | THIN — needs more authoritative content                    |
| Sub-Zero            | 1,987 | GOOD                                                       |
| Contact             | 761   | ACCEPTABLE for a contact page                              |

#### Content Similarity (Duplicate Content Risk)

Analysis of service pages reveals 37-44% content overlap between pages. This is primarily from:

- Shared navigation, footer, CTA section, and service area list (structural duplication)
- Different unique content sections per page

At 37-44% similarity, this is **borderline acceptable** — below the typically concerning 50%+ threshold. However, the service area cities section and CTA section are nearly identical across all pages. This could be improved by implementing more unique location-specific content per service page.

#### Content Gaps (HIGH PRIORITY)

1. **No blog/resource center** — Zero informational content. Unable to rank for "how to fix refrigerator not cooling", "appliance repair cost guide", "when to repair vs replace" — these are high-intent queries
2. **No location pages** — Despite serving 20+ cities (listed on every page), there are no dedicated city-level pages (e.g., `/la-jolla/`, `/encinitas/appliance-repair/`)
3. **No About Us page** — No team page, no company story, weakens E-E-A-T
4. **No Pricing page** — FAQ answers pricing questions but no transparent pricing page
5. **No customer reviews/testimonials** — The site mentions "50K+ repairs" but shows zero social proof from customers

#### AI Search (GEO) Readiness

| GEO Signal                       | Status                                                                     |
| -------------------------------- | -------------------------------------------------------------------------- |
| Direct Answer in first 150 words | PARTIAL — meta description answers "what" but page opens with H1 + tagline |
| FAQ Schema with answers          | PASS — 7 FAQs on homepage, 5-6 on service pages                            |
| Data in tables                   | PARTIAL — service response time table on homepage is good                  |
| JSON-LD Schema                   | PASS (but incomplete — see Schema section)                                 |
| Original first-party data        | PASS — "15+ years", "50K+ repairs" are proprietary claims                  |
| Key Takeaways / Summary box      | PARTIAL — homepage has a "Key Takeaway" callout section                    |
| External citations / sources     | MISSING                                                                    |

**GEO Score**: 58/100 — Adequate FAQ schema and some data tables, but lacks citations, expert attribution, and structured Q&A answers that AI engines favor.

---

## Schema / Structured Data

### Score: 65 / 100

#### Current Implementation

**Homepage**:

- LocalBusiness — COMPLETE (name, telephone, address, geo, serviceArea, openingHours, priceRange, hasOfferCatalog)
- FAQPage — 7 questions with full answers

**Service pages** (refrigerator-repair, washer-repair, etc.):

- LocalBusiness — present
- Service — present (basic)
- BreadcrumbList — present
- FAQPage — present (4-6 questions)

**Brand pages** (sub-zero, brands/ hub):

- BreadcrumbList — present
- FAQPage — present
- LocalBusiness — **MISSING**
- Service — **MISSING**

**Contact page**:

- LocalBusiness — present
- BreadcrumbList — present
- FAQPage — present

#### Schema Issues

| Issue                                          | Priority | Pages Affected                  |
| ---------------------------------------------- | -------- | ------------------------------- |
| AggregateRating missing from all service pages | HIGH     | All 10 service pages            |
| AggregateRating missing from brand pages       | HIGH     | All 15 brand pages              |
| LocalBusiness missing from brand pages         | MEDIUM   | brands/ hub, all 15 brand pages |
| Service schema missing from brand pages        | MEDIUM   | brands/ hub, all 15 brand pages |
| Organization schema missing from all pages     | LOW      | Sitewide                        |
| WebSite schema with SearchAction missing       | LOW      | Homepage                        |
| Review schema (individual reviews) missing     | MEDIUM   | Service + brand pages           |

#### LocalBusiness Schema — NAP Validation

| Field           | Homepage Schema              | Contact Schema               | Match |
| --------------- | ---------------------------- | ---------------------------- | ----- |
| name            | Carlsbad A-Tech              | Carlsbad A-Tech              | YES   |
| telephone       | +1-760-555-0147              | +1-760-555-0147              | YES   |
| streetAddress   | 2855 Carlsbad Blvd Suite 100 | 2855 Carlsbad Blvd Suite 100 | YES   |
| addressLocality | Carlsbad                     | Carlsbad                     | YES   |
| addressRegion   | CA                           | CA                           | YES   |
| postalCode      | 92008                        | 92008                        | YES   |

NAP is consistent across schema — good. The visible phone `(760) 555-0147` matches the schema `+1-760-555-0147` — consistent.

---

## Images

### Score: 82 / 100

| Check                         | Status                                                                                                              |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| Alt text on all images        | PASS — 0 images missing alt text                                                                                    |
| Empty alt attributes          | PASS — 0 empty alt attributes                                                                                       |
| Alt text quality              | GOOD — descriptive alt text found (e.g., "Carlsbad A-Tech technician repairing a refrigerator in a San Diego home") |
| WebP format                   | PASS — all images use .webp format                                                                                  |
| Image sizes                   | GOOD — hero image is only 8 KB (well optimized)                                                                     |
| Lazy loading                  | PARTIAL — only 1 lazy-loaded element found sitewide                                                                 |
| Explicit width/height in HTML | MISSING — no width/height attributes on img tags (CLS risk)                                                         |
| Image sitemap                 | MISSING                                                                                                             |

#### Issues

1. **No width/height attributes on `<img>` tags** — Without explicit dimensions, the browser cannot reserve layout space before images load, causing potential CLS (Cumulative Layout Shift). Add `width` and `height` attributes to all images.
2. **Image count is very low** — Most pages have 1-2 images total. Richer visual content (repair process photos, technician photos, before/after) would improve engagement and E-E-A-T.
3. **No image sitemap** — Adding `<image:image>` elements to sitemap.xml enables Google Image Search indexing.

---

## Internal Linking

### Score: 68 / 100

#### Positive

- Service pages link to other service pages in both navigation and footer
- Brand pages link to related services and other brands
- Breadcrumb navigation is implemented on all inner pages
- Hub pages (`/services/`, `/brands/`) are properly linked from inner page navigation

#### Issues

| Issue                                                                                 | Priority |
| ------------------------------------------------------------------------------------- | -------- |
| Homepage "Contact" nav links to #contact anchor instead of contact.html               | HIGH     |
| Homepage footer does not link to /contact.html                                        | HIGH     |
| Homepage footer does not link to /services/ hub                                       | MEDIUM   |
| Homepage footer does not link to /brands/ hub                                         | MEDIUM   |
| Homepage nav "Services" dropdown links to individual pages but not /services/ hub     | MEDIUM   |
| No cross-linking between service pages and related brand pages in body content        | MEDIUM   |
| Footer nav doesn't include Dacor, Gaggenau, Jenn-Air, Viking, Wolf, Miele, KitchenAid | LOW      |
| No external links to authoritative sources (manufacturer sites, BBB, etc.)            | LOW      |

#### Anchor Text Analysis

- "Learn More" is used as generic anchor text for all service cards on homepage — low SEO value, should be descriptive ("Learn About Washer Repair", etc.)
- Internal links generally use keyword-rich anchor text in nav (e.g., "Refrigerator Repair", "Sub-Zero")
- No brand-to-service cross-linking (e.g., Sub-Zero brand page doesn't link to Refrigerator Repair service page with "Sub-Zero refrigerator repair" anchor)

#### Orphan Pages

- `/contact.html` — Linked only from inner page navigation (service/brand pages) but NOT from homepage. Orphan from homepage perspective.
- `/services/` hub — Not linked from homepage nav dropdown (only individual service pages are) or footer
- `/brands/` hub — Not linked from homepage footer

---

## Open Graph / Social

### Score: 55 / 100

| Page                | og:title | og:image | og:description | twitter:card |
| ------------------- | -------- | -------- | -------------- | ------------ |
| Homepage            | YES      | **NO**   | YES            | **NO**       |
| Contact             | YES      | YES      | YES            | **NO**       |
| Services hub        | YES      | YES      | YES            | YES          |
| Refrigerator Repair | YES      | YES      | YES            | **NO**       |
| Brands hub          | YES      | YES      | YES            | **NO**       |
| Sub-Zero            | YES      | YES      | YES            | **NO**       |

- Homepage is missing `og:image` — critical since it's the most likely shared URL
- Twitter Card is only present on `/services/` hub — missing from homepage and all other pages
- `og:type` is `website` on homepage — for local business, `local.business` would be more accurate
- No `og:image:width` and `og:image:height` meta tags present on any page (should accompany og:image)

---

## Performance Summary

### Score: 88 / 100

| Metric                    | Value             | Assessment   |
| ------------------------- | ----------------- | ------------ |
| Server response time      | 29ms              | EXCELLENT    |
| Total HTML size           | 68 KB             | GOOD (small) |
| Total CSS                 | 29 KB (26 + 3)    | GOOD         |
| JS bundle                 | 2.9 KB (deferred) | EXCELLENT    |
| Hero image                | 8 KB webp         | EXCELLENT    |
| Render-blocking CSS       | 2 files           | MINOR ISSUE  |
| Render-blocking JS        | 0 (defer)         | PASS         |
| LCP candidate (estimated) | hero image        | GOOD         |
| Preload hints             | 0                 | OPPORTUNITY  |
| Third-party scripts       | 0                 | EXCELLENT    |

Total estimated page weight: ~108 KB — very lightweight. This site should achieve excellent Core Web Vitals scores in the field.

---

## Summary Scorecard

| Category                 | Weight   | Score | Weighted      |
| ------------------------ | -------- | ----- | ------------- |
| Technical SEO            | 25%      | 84    | 21.0          |
| Content Quality          | 25%      | 72    | 18.0          |
| On-Page SEO              | 20%      | 78    | 15.6          |
| Schema / Structured Data | 10%      | 65    | 6.5           |
| Performance (CWV)        | 10%      | 88    | 8.8           |
| Images                   | 5%       | 82    | 4.1           |
| AI Search Readiness      | 5%       | 58    | 2.9           |
| **TOTAL**                | **100%** | —     | **76.9 ≈ 74** |

_Final score adjusted to 74 to account for cross-cutting issues (social meta inconsistency, missing content types, navigation issues)_

---

_Report generated: 2026-02-19 | Audit tool: seo-audit skill | Crawler: curl + HTML analysis_
