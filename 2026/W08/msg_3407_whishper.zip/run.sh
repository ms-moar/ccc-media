#!/bin/bash
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  🎙️ WhisperApp — установка и запуск (macOS / Linux)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV_DIR="$SCRIPT_DIR/.venv"

echo ""
echo "  🎙️  WhisperApp — бесплатная транскрибация"
echo "  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# ── Check Python ────────────────────────────────────
if command -v python3 &>/dev/null; then
    PYTHON=python3
elif command -v python &>/dev/null; then
    PYTHON=python
else
    echo "❌ Python не найден!"
    echo "   Установи Python 3.10+: https://www.python.org/downloads/"
    echo "   Или через Homebrew:  brew install python@3.11"
    exit 1
fi

PY_VERSION=$($PYTHON -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "  ✅ Python $PY_VERSION"

# ── Create venv if not exists ───────────────────────
if [ ! -d "$VENV_DIR" ]; then
    echo "  📦 Создаю виртуальное окружение…"
    $PYTHON -m venv "$VENV_DIR"
fi

source "$VENV_DIR/bin/activate"

# ── Install / upgrade deps ─────────────────────────
echo "  📥 Проверяю зависимости…"
pip install --quiet --upgrade pip
pip install --quiet -r "$SCRIPT_DIR/requirements.txt"

# ── FFmpeg check ────────────────────────────────────
if ! command -v ffmpeg &>/dev/null; then
    echo ""
    echo "  ⚠️  FFmpeg не найден (нужен для видео/аудио конвертации)."
    echo "     Установи:  brew install ffmpeg"
    echo "     Без него будут работать только WAV файлы."
    echo ""
fi

# ── Launch ──────────────────────────────────────────
echo ""
echo "  🚀 Запускаю WhisperApp…"
echo "  🌐 Открой в браузере: http://127.0.0.1:7860"
echo ""

cd "$SCRIPT_DIR"
$PYTHON whisper_app.py "$@"
