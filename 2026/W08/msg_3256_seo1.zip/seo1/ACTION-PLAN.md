# SEO Action Plan — seo1.moar.tools

**Business**: Carlsbad A-Tech — Appliance Repair San Diego
**Date**: 2026-02-19
**Overall Score**: 74 / 100

---

## CRITICAL — Fix Immediately

### C1. Fix homepage "Contact" navigation link

**Problem**: The nav "Contact" item on the homepage uses `href="#contact"` which scrolls to a CTA form. The dedicated `/contact.html` page has no incoming link from homepage, making it effectively an orphan from Google's homepage crawl.

**Fix**: Update the homepage nav Contact link to `href="contact.html"` (or `/contact.html`). Also add a link to `contact.html` in the homepage footer column.

**File**: `index.html`
**Impact**: Crawl equity, indexation of contact page, UX

---

### C2. Add og:image to homepage

**Problem**: Homepage has no `og:image` meta tag. When the homepage URL is shared on social media or appears in AI chat previews, no image is shown.

**Fix**: Add to `<head>` of `index.html`:

```html
<meta
  property="og:image"
  content="https://seo1.moar.tools/assets/img/home-1.webp"
/>
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<meta
  property="og:image:alt"
  content="Carlsbad A-Tech appliance repair technician San Diego"
/>
```

If the current hero image is not 1200x630, create a proper social sharing image at that size.

**File**: `index.html`
**Impact**: Social CTR, AI snippet appearance, brand presence

---

### C3. Add Twitter Card meta tags to all pages missing them

**Problem**: Only `/services/` hub has Twitter Card. Homepage, contact, all service pages, all brand pages are missing `twitter:card`.

**Fix**: Add to all pages missing Twitter Card:

```html
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="[Same as og:title]" />
<meta name="twitter:description" content="[Same as og:description]" />
<meta name="twitter:image" content="[Same as og:image URL]" />
```

**Files**: `index.html`, `contact.html`, all service pages, all brand pages
**Impact**: Twitter/X sharing appearance

---

## HIGH — Fix Within 1 Week

### H1. Add AggregateRating schema to service pages

**Problem**: No star ratings appear in Google search results for any service or brand page despite the business having "50K+ repairs completed". This is a major rich snippet opportunity being missed.

**Fix**: Add AggregateRating inside the existing LocalBusiness JSON-LD on each service page:

```json
"aggregateRating": {
  "@type": "AggregateRating",
  "ratingValue": "4.9",
  "reviewCount": "312",
  "bestRating": "5",
  "worstRating": "1"
}
```

Use real review counts from Google Business Profile or Yelp. Add the same to the main LocalBusiness schema on the homepage.

**Files**: All 10 service pages, `index.html`
**Impact**: Rich snippets in SERP, CTR improvement (+20-30% estimated)

---

### H2. Add LocalBusiness + Service schema to brand pages

**Problem**: All 15 brand pages and the brands/ hub lack LocalBusiness and Service schema. They only have BreadcrumbList and FAQPage.

**Fix**: Add to each brand page (e.g., `brands/sub-zero.html`):

```json
{
  "@type": "Service",
  "@id": "https://seo1.moar.tools/brands/sub-zero.html#service",
  "name": "Sub-Zero Appliance Repair",
  "provider": {
    "@type": "LocalBusiness",
    "name": "Carlsbad A-Tech",
    "@id": "https://seo1.moar.tools/#business"
  },
  "areaServed": {
    "@type": "City",
    "name": "San Diego",
    "sameAs": "https://en.wikipedia.org/wiki/San_Diego"
  },
  "serviceType": "Appliance Repair"
}
```

**Files**: All 15 brand pages, `brands/index.html`
**Impact**: Better Google understanding of brand repair pages, eligible for richer search appearance

---

### H3. Fix "Learn More" anchor text on homepage service cards

**Problem**: All service cards on the homepage use "Learn More →" as link text. This provides no SEO value and is generic.

**Fix**: Replace each "Learn More →" link with descriptive text:

- "Learn More" for Refrigerator Repair → "Refrigerator Repair Details"
- "Learn More" for Washer Repair → "Washer Repair Service"
- etc.

**File**: `index.html`
**Impact**: Internal link anchor text signals, keyword relevance

---

### H4. Add links to /services/ hub and /brands/ hub in homepage footer

**Problem**: Homepage footer links directly to individual service and brand pages but skips the hub pages entirely.

**Fix**: Add to footer navigation:

- "All Services" → `services/`
- "All Brands" → `brands/`

**File**: `index.html`
**Impact**: Crawl equity distribution to hub pages, internal linking completeness

---

### H5. Add preload hint for hero image (LCP optimization)

**Problem**: No `<link rel="preload">` for the hero image. The browser discovers the image only after parsing HTML and CSS, adding ~100-200ms to LCP.

**Fix**: Add as the first `<link>` in `<head>` on each page that has a hero image:

```html
<link rel="preload" as="image" href="assets/img/home-1.webp" />
```

Apply to: `index.html`, each service page with its hero image, each brand page with its hero image.

**Files**: `index.html` and all pages with hero images
**Impact**: LCP improvement, potential Core Web Vitals gain

---

## MEDIUM — Fix Within 1 Month

### M1. Create About Us / About the Team page

**Problem**: No About page weakens E-E-A-T signals. Local service businesses benefit significantly from showing real people behind the company.

**Content to include**:

- Company founding story (year, why started)
- Key technicians with photos and certifications
- Manufacturer certification badges (Sub-Zero, Viking, Thermador authorized)
- BBB rating, license number (CA contractor license)
- Awards or media mentions

**New file**: `about.html`
**Impact**: E-E-A-T, trust signals, conversion rate

---

### M2. Add customer testimonials / reviews section

**Problem**: The site claims 50K+ repairs but displays zero customer reviews. This is the single biggest trust gap for a local service business.

**Fix options**:

1. Embed Google Business Profile reviews widget
2. Add static HTML review cards (with AggregateRating schema)
3. Add a `/reviews.html` page and link from homepage

**Minimum**: Add 5-8 customer testimonials with star ratings to homepage (above the FAQ section). Add Review schema:

```json
{
  "@type": "Review",
  "reviewRating": { "@type": "Rating", "ratingValue": "5" },
  "author": { "@type": "Person", "name": "Jennifer M." },
  "reviewBody": "..."
}
```

**Files**: `index.html`, optionally new `reviews.html`
**Impact**: Trust, conversion, AggregateRating schema enablement

---

### M3. Add explicit width/height to all img tags

**Problem**: No `<img>` tag has explicit `width` and `height` attributes. This causes CLS (layout shift) when images load.

**Fix**: For every image, add matching dimensions:

```html
<img src="assets/img/home-1.webp" alt="..." width="800" height="533" />
```

Measure actual image dimensions first.

**Files**: All HTML files
**Impact**: CLS improvement, Core Web Vitals

---

### M4. Consolidate CSS files

**Problem**: Two CSS files (`main.css` 26KB + `responsive.css` 3KB) create two render-blocking HTTP requests.

**Fix**: Concatenate into a single `main.css` file and update the `<link>` tag.

**Estimated savings**: 1 HTTP round-trip (~5-10ms on LAN, more on mobile)

**Files**: All HTML files, `assets/css/`
**Impact**: Minor LCP improvement

---

### M5. Create a custom branded 404 page

**Problem**: The site returns a bare nginx default 404 page. Users who land on a non-existent URL see no navigation, no branding, and no path forward.

**Fix**: Create `404.html` with site navigation, phone number, links to popular services. Configure nginx with `error_page 404 /404.html`.

**New file**: `404.html`
**Impact**: Bounce rate, user experience, brand consistency

---

### M6. Add HSTS security header

**Problem**: `Strict-Transport-Security` header is missing. Without it, browsers may make initial HTTP requests before being redirected.

**Fix**: Add to nginx configuration:

```nginx
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
```

**Impact**: Security posture, minor SEO trust signal

---

### M7. Add og:image:width/height to all pages with og:image

**Problem**: Pages that have `og:image` (contact, services/, service pages, brand pages) are missing the companion `og:image:width` and `og:image:height` tags. Without these, scrapers may not know the image dimensions.

**Fix**: Add alongside each `og:image`:

```html
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
```

**Files**: `contact.html`, `services/index.html`, all service and brand pages
**Impact**: Better social card display

---

### M8. Create pricing page

**Problem**: No transparent pricing page. The FAQ addresses cost in general terms but a dedicated pricing page builds trust and can rank for "[service] repair cost San Diego" queries.

**New file**: `pricing.html`
**Content**:

- Diagnostic fee (waived with repair)
- Typical range per appliance type
- What affects pricing
- FAQ (min charge, same-day surcharge, warranty)

**Impact**: New keyword ranking opportunity, trust, conversion

---

## LOW — Backlog

### L1. Add WebSite schema with SearchAction to homepage

```json
{
  "@type": "WebSite",
  "@id": "https://seo1.moar.tools/#website",
  "url": "https://seo1.moar.tools/",
  "name": "Carlsbad A-Tech",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://seo1.moar.tools/?s={search_term_string}",
    "query-input": "required name=search_term_string"
  }
}
```

### L2. Add Organization schema with sameAs links

Add social profile URLs to schema (Google Business, Yelp, BBB):

```json
"sameAs": [
  "https://www.yelp.com/biz/carlsbad-a-tech",
  "https://www.google.com/maps/...",
  "https://www.bbb.org/..."
]
```

### L3. Add image sitemap entries

Extend `sitemap.xml` to include `<image:image>` namespace entries for all images.

### L4. Replace generic "Learn More" CTAs on service section cards

Already covered in H3 above. Also apply to brand page card CTAs.

### L5. Add sitemap link in footer

Add `<a href="/sitemap.xml">Sitemap</a>` in the footer for completeness.

### L6. Replace deprecated `x-xss-protection` header

The `X-XSS-Protection: 1; mode=block` header is deprecated in modern browsers. Remove it and rely on Content-Security-Policy instead.

### L7. Create an About/Bio page for individual technicians

Creates E-E-A-T author pages that can be referenced with `expert` credentials in content.

---

## Strategic Opportunities (Beyond Technical Fixes)

### SO1. Build city-level location pages (HIGH potential)

The site already mentions 20+ service cities (Carlsbad, Encinitas, Oceanside, La Jolla, etc.) but has no dedicated pages for them.

**Opportunity**: Create `/locations/la-jolla-appliance-repair.html`, `/locations/encinitas-appliance-repair.html`, etc. Each page should:

- Target "[city] appliance repair" keyword
- Include a LocalBusiness with specific city address/area
- List services available in that city
- Include unique local content (driving directions, neighborhood references)
- Have proper canonical to avoid duplication

**Estimated volume**: 20 city pages × average 200 monthly searches = 4,000+ additional monthly search opportunities

### SO2. Launch a blog / resource center (HIGH potential)

Zero informational content means zero ability to rank for top-of-funnel queries.

**Priority content topics**:

1. "How to tell if your refrigerator compressor is failing" (2,400/mo)
2. "Appliance repair vs replacement: cost guide 2026" (1,600/mo)
3. "How long do washing machines last?" (1,300/mo)
4. "Sub-Zero refrigerator maintenance tips" (900/mo)
5. "Why is my dryer not heating? Troubleshooting guide" (2,200/mo)

Each article should:

- Target a specific keyword with clear search intent
- Include FAQ schema
- Link to the relevant service page
- Be 1,500-2,500 words
- Include the GEO-first structure (direct answer in first paragraph)

### SO3. Build Google Business Profile citations

The website is well-structured but has no visible external authority signals. Priority:

1. Claim and fully optimize Google Business Profile
2. List on Yelp, Angi, HomeAdvisor, Thumbtack
3. Get listed on BBB (Better Business Bureau)
4. Add sameAs links to schema once profiles exist

### SO4. Build brand-specific cross-links in body content

Currently, brand pages (e.g., sub-zero.html) do not contextually link to relevant service pages within body content. Example: Sub-Zero page should link to `/services/refrigerator-repair.html` with anchor "Sub-Zero refrigerator repair San Diego". This creates topical authority signals.

---

## Implementation Priority Matrix

| Task                            | Impact    | Effort    | Priority     |
| ------------------------------- | --------- | --------- | ------------ |
| C1. Fix Contact nav link        | Medium    | Low       | Do today     |
| C2. Add og:image homepage       | High      | Low       | Do today     |
| C3. Add Twitter Cards all pages | Medium    | Low       | Do today     |
| H1. AggregateRating schema      | High      | Medium    | This week    |
| H2. Schema on brand pages       | Medium    | Medium    | This week    |
| H3. Fix "Learn More" anchors    | Medium    | Low       | This week    |
| H4. Footer links to hubs        | Low       | Low       | This week    |
| H5. Preload hero image          | Medium    | Low       | This week    |
| M1. About Us page               | High      | High      | This month   |
| M2. Customer testimonials       | High      | Medium    | This month   |
| M3. img width/height attrs      | Medium    | Low       | This month   |
| SO1. City location pages        | Very High | High      | Next quarter |
| SO2. Blog / content hub         | Very High | Very High | Next quarter |
| SO3. GBP + citations            | Very High | Medium    | Next quarter |

---

_Action Plan generated: 2026-02-19 | Based on FULL-AUDIT-REPORT.md_
