/* Carlsbad A-Tech — Main JS */
(function () {
  "use strict";

  /* --- Hamburger Menu --- */
  var hamburger = document.querySelector(".hamburger");
  var mobileNav = document.querySelector(".mobile-nav");

  if (hamburger && mobileNav) {
    hamburger.addEventListener("click", function () {
      hamburger.classList.toggle("active");
      mobileNav.classList.toggle("active");
      document.body.style.overflow = mobileNav.classList.contains("active")
        ? "hidden"
        : "";
      hamburger.setAttribute(
        "aria-expanded",
        mobileNav.classList.contains("active"),
      );
    });

    mobileNav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        hamburger.classList.remove("active");
        mobileNav.classList.remove("active");
        document.body.style.overflow = "";
      });
    });
  }

  /* --- FAQ Accordion --- */
  document.querySelectorAll(".faq-question").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var item = btn.closest(".faq-item");
      var isActive = item.classList.contains("active");

      item
        .closest(".faq-section")
        .querySelectorAll(".faq-item")
        .forEach(function (el) {
          el.classList.remove("active");
        });

      if (!isActive) {
        item.classList.add("active");
      }
    });
  });

  /* --- Form Validation --- */
  document
    .querySelectorAll(".cta-form, .contact-form")
    .forEach(function (form) {
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        var valid = true;
        form.querySelectorAll("[required]").forEach(function (input) {
          if (!input.value.trim()) {
            input.style.borderColor = "var(--color-error)";
            valid = false;
          } else {
            input.style.borderColor = "";
          }
        });

        var phone = form.querySelector('input[type="tel"]');
        if (phone && phone.value && !/^[\d\s\-\(\)\+]{7,}$/.test(phone.value)) {
          phone.style.borderColor = "var(--color-error)";
          valid = false;
        }

        if (valid) {
          var btn = form.querySelector('button[type="submit"]');
          if (btn) {
            var orig = btn.textContent;
            btn.textContent = "Request Sent!";
            btn.disabled = true;
            setTimeout(function () {
              btn.textContent = orig;
              btn.disabled = false;
              form.reset();
            }, 3000);
          }
        }
      });
    });

  /* --- Sticky header shadow --- */
  var header = document.querySelector(".header");
  if (header) {
    window.addEventListener(
      "scroll",
      function () {
        if (window.scrollY > 10) {
          header.style.boxShadow = "0 2px 12px rgba(0,0,0,0.1)";
        } else {
          header.style.boxShadow = "";
        }
      },
      { passive: true },
    );
  }
})();
