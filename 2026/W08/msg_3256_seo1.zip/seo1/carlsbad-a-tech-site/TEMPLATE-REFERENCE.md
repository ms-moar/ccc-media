# Template Reference for Carlsbad A-Tech Pages

## Company Info (NAP)

- **Name**: Carlsbad A-Tech
- **Tagline**: Professional Appliance Repair in San Diego
- **Service Area**: San Diego County, CA
- **HQ**: Carlsbad, CA
- **Phone**: (760) 555-0137
- **Email**: service@carlsbadatech.com
- **Hours**: Monday–Saturday 8:00 AM – 6:00 PM, Sunday: Emergency Only
- **License**: CA Licensed & Insured
- **Experience**: 15+ years, 10,000+ repairs completed

## FORBIDDEN WORDS

- ❌ "authorized" / "authorized service" / "authorized repair"
- ✅ Use: "certified", "trained", "experienced", "skilled", "factory-trained"

## Neighborhoods (Service Areas)

Clairemont, Hillcrest, La Jolla, Little Italy, Mira Mesa, Mission Valley, North Park, Ocean Beach, Pacific Beach, Point Loma, Rancho Bernardo, San Diego Downtown, Carlsbad, Encinitas, Oceanside, Escondido, Del Mar, Solana Beach, Vista, San Marcos, Poway, Scripps Ranch, Carmel Valley, University City, Kearny Mesa

## HTML Document Template

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>{PAGE_TITLE} | Carlsbad A-Tech</title>
    <meta name="description" content="{META_DESCRIPTION}" />
    <link rel="canonical" href="https://carlsbadatech.com/{PATH}" />
    <!-- Open Graph -->
    <meta property="og:title" content="{OG_TITLE}" />
    <meta property="og:description" content="{OG_DESCRIPTION}" />
    <meta property="og:url" content="https://carlsbadatech.com/{PATH}" />
    <meta property="og:type" content="website" />
    <meta
      property="og:image"
      content="https://carlsbadatech.com/assets/img/{OG_IMAGE}"
    />
    <meta property="og:site_name" content="Carlsbad A-Tech" />
    <!-- Favicon -->
    <link rel="icon" href="{ROOT}favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="{ROOT}assets/img/apple-touch-icon.png" />
    <!-- CSS -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="{ROOT}assets/css/main.css" />
    <link rel="stylesheet" href="{ROOT}assets/css/responsive.css" />
    <!-- JSON-LD structured data goes here -->
  </head>
  <body>
    <!-- HEADER (same on all pages) -->
    <!-- BREADCRUMBS (on child pages only) -->
    <!-- PAGE CONTENT -->
    <!-- CTA SECTION -->
    <!-- FAQ SECTION -->
    <!-- FOOTER (same on all pages) -->
    <script src="{ROOT}assets/js/main.js" defer></script>
  </body>
</html>
```

## Root Path Variable ({ROOT})

- Pages in root (index.html, contact.html): `{ROOT}` = `` (empty or`./`)
- Pages in /services/: `{ROOT}` = `../`
- Pages in /brands/: `{ROOT}` = `../`

## Standard Header HTML

```html
<header class="site-header">
  <div class="container">
    <a href="{ROOT}index.html" class="logo" aria-label="Carlsbad A-Tech Home">
      <span class="logo__icon">CA</span>
      <span>Carlsbad A-Tech</span>
    </a>
    <nav class="nav-desktop" aria-label="Main navigation">
      <div class="nav-desktop__item">
        <a href="{ROOT}index.html" class="nav-desktop__link">Home</a>
      </div>
      <div class="nav-desktop__item">
        <a href="{ROOT}services/index.html" class="nav-desktop__link"
          >Services <span class="nav-desktop__arrow">▼</span></a
        >
        <div class="dropdown">
          <a
            href="{ROOT}services/refrigerator-repair.html"
            class="dropdown__link"
            >Refrigerator Repair</a
          >
          <a href="{ROOT}services/washer-repair.html" class="dropdown__link"
            >Washer Repair</a
          >
          <a href="{ROOT}services/dryer-repair.html" class="dropdown__link"
            >Dryer Repair</a
          >
          <a href="{ROOT}services/oven-repair.html" class="dropdown__link"
            >Oven Repair</a
          >
          <a href="{ROOT}services/stove-repair.html" class="dropdown__link"
            >Stove Repair</a
          >
          <a
            href="{ROOT}services/kitchen-range-repair.html"
            class="dropdown__link"
            >Kitchen Range Repair</a
          >
          <a href="{ROOT}services/dishwasher-repair.html" class="dropdown__link"
            >Dishwasher Repair</a
          >
          <a href="{ROOT}services/microwave-repair.html" class="dropdown__link"
            >Microwave Repair</a
          >
          <a href="{ROOT}services/freezer-repair.html" class="dropdown__link"
            >Freezer Repair</a
          >
          <a href="{ROOT}services/ice-maker-repair.html" class="dropdown__link"
            >Ice Maker Repair</a
          >
        </div>
      </div>
      <div class="nav-desktop__item">
        <a href="{ROOT}brands/index.html" class="nav-desktop__link"
          >Brands <span class="nav-desktop__arrow">▼</span></a
        >
        <div class="dropdown">
          <a href="{ROOT}brands/sub-zero.html" class="dropdown__link"
            >Sub-Zero</a
          >
          <a href="{ROOT}brands/dacor.html" class="dropdown__link">Dacor</a>
          <a href="{ROOT}brands/viking.html" class="dropdown__link">Viking</a>
          <a href="{ROOT}brands/thermador.html" class="dropdown__link"
            >Thermador</a
          >
          <a href="{ROOT}brands/gaggenau.html" class="dropdown__link"
            >Gaggenau</a
          >
          <a href="{ROOT}brands/bosch.html" class="dropdown__link">Bosch</a>
          <a href="{ROOT}brands/miele.html" class="dropdown__link">Miele</a>
          <a href="{ROOT}brands/wolf.html" class="dropdown__link">Wolf</a>
          <a href="{ROOT}brands/kitchenaid.html" class="dropdown__link"
            >KitchenAid</a
          >
          <a href="{ROOT}brands/jenn-air.html" class="dropdown__link"
            >Jenn-Air</a
          >
          <a href="{ROOT}brands/lg.html" class="dropdown__link">LG</a>
          <a href="{ROOT}brands/maytag.html" class="dropdown__link">Maytag</a>
          <a href="{ROOT}brands/samsung.html" class="dropdown__link">Samsung</a>
          <a href="{ROOT}brands/ge.html" class="dropdown__link">GE</a>
        </div>
      </div>
      <div class="nav-desktop__item">
        <a href="{ROOT}contact.html" class="nav-desktop__link">Contact</a>
      </div>
    </nav>
    <a href="{ROOT}contact.html" class="btn btn--primary header-cta"
      >Request Service</a
    >
    <button class="hamburger" aria-label="Toggle menu" aria-expanded="false">
      <span class="hamburger__line"></span>
      <span class="hamburger__line"></span>
      <span class="hamburger__line"></span>
    </button>
  </div>
</header>
<!-- Mobile Navigation -->
<nav class="nav-mobile" aria-label="Mobile navigation">
  <a href="{ROOT}index.html" class="nav-mobile__link">Home</a>
  <button class="nav-mobile__toggle">
    Services <span class="nav-mobile__toggle-arrow">▼</span>
  </button>
  <div class="nav-mobile__sub">
    <a href="{ROOT}services/index.html" class="nav-mobile__sub-link"
      >All Services</a
    >
    <a
      href="{ROOT}services/refrigerator-repair.html"
      class="nav-mobile__sub-link"
      >Refrigerator Repair</a
    >
    <a href="{ROOT}services/washer-repair.html" class="nav-mobile__sub-link"
      >Washer Repair</a
    >
    <a href="{ROOT}services/dryer-repair.html" class="nav-mobile__sub-link"
      >Dryer Repair</a
    >
    <a href="{ROOT}services/oven-repair.html" class="nav-mobile__sub-link"
      >Oven Repair</a
    >
    <a href="{ROOT}services/stove-repair.html" class="nav-mobile__sub-link"
      >Stove Repair</a
    >
    <a
      href="{ROOT}services/kitchen-range-repair.html"
      class="nav-mobile__sub-link"
      >Kitchen Range Repair</a
    >
    <a href="{ROOT}services/dishwasher-repair.html" class="nav-mobile__sub-link"
      >Dishwasher Repair</a
    >
    <a href="{ROOT}services/microwave-repair.html" class="nav-mobile__sub-link"
      >Microwave Repair</a
    >
    <a href="{ROOT}services/freezer-repair.html" class="nav-mobile__sub-link"
      >Freezer Repair</a
    >
    <a href="{ROOT}services/ice-maker-repair.html" class="nav-mobile__sub-link"
      >Ice Maker Repair</a
    >
  </div>
  <button class="nav-mobile__toggle">
    Brands <span class="nav-mobile__toggle-arrow">▼</span>
  </button>
  <div class="nav-mobile__sub">
    <a href="{ROOT}brands/index.html" class="nav-mobile__sub-link"
      >All Brands</a
    >
    <a href="{ROOT}brands/sub-zero.html" class="nav-mobile__sub-link"
      >Sub-Zero</a
    >
    <a href="{ROOT}brands/dacor.html" class="nav-mobile__sub-link">Dacor</a>
    <a href="{ROOT}brands/viking.html" class="nav-mobile__sub-link">Viking</a>
    <a href="{ROOT}brands/thermador.html" class="nav-mobile__sub-link"
      >Thermador</a
    >
    <a href="{ROOT}brands/gaggenau.html" class="nav-mobile__sub-link"
      >Gaggenau</a
    >
    <a href="{ROOT}brands/bosch.html" class="nav-mobile__sub-link">Bosch</a>
    <a href="{ROOT}brands/miele.html" class="nav-mobile__sub-link">Miele</a>
    <a href="{ROOT}brands/wolf.html" class="nav-mobile__sub-link">Wolf</a>
    <a href="{ROOT}brands/kitchenaid.html" class="nav-mobile__sub-link"
      >KitchenAid</a
    >
    <a href="{ROOT}brands/jenn-air.html" class="nav-mobile__sub-link"
      >Jenn-Air</a
    >
    <a href="{ROOT}brands/lg.html" class="nav-mobile__sub-link">LG</a>
    <a href="{ROOT}brands/maytag.html" class="nav-mobile__sub-link">Maytag</a>
    <a href="{ROOT}brands/samsung.html" class="nav-mobile__sub-link">Samsung</a>
    <a href="{ROOT}brands/ge.html" class="nav-mobile__sub-link">GE</a>
  </div>
  <a href="{ROOT}contact.html" class="nav-mobile__link">Contact</a>
  <a href="{ROOT}contact.html" class="btn btn--primary btn--block mt-lg"
    >Request Service</a
  >
</nav>
```

## Standard Footer HTML

```html
<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-col">
        <div class="footer-col__title">Carlsbad A-Tech</div>
        <div class="footer-info">
          <p>
            Professional appliance repair serving San Diego County. Our
            certified technicians deliver reliable, same-day repair solutions
            for all major brands and appliance types.
          </p>
          <p>
            <strong>Phone:</strong>
            <a href="tel:+17605550137" class="phone-link">(760) 555-0137</a>
          </p>
          <p>
            <strong>Email:</strong>
            <a href="mailto:service@carlsbadatech.com"
              >service@carlsbadatech.com</a
            >
          </p>
          <p><strong>Hours:</strong> Mon–Sat 8AM–6PM | Sun: Emergency Only</p>
          <p><strong>Service Area:</strong> San Diego County, CA</p>
          <p><strong>License:</strong> CA Licensed &amp; Insured</p>
        </div>
      </div>
      <div class="footer-col">
        <div class="footer-col__title">Services</div>
        <a href="{ROOT}services/refrigerator-repair.html"
          >Refrigerator Repair</a
        >
        <a href="{ROOT}services/washer-repair.html">Washer Repair</a>
        <a href="{ROOT}services/dryer-repair.html">Dryer Repair</a>
        <a href="{ROOT}services/oven-repair.html">Oven Repair</a>
        <a href="{ROOT}services/stove-repair.html">Stove Repair</a>
        <a href="{ROOT}services/kitchen-range-repair.html"
          >Kitchen Range Repair</a
        >
        <a href="{ROOT}services/dishwasher-repair.html">Dishwasher Repair</a>
        <a href="{ROOT}services/microwave-repair.html">Microwave Repair</a>
        <a href="{ROOT}services/freezer-repair.html">Freezer Repair</a>
        <a href="{ROOT}services/ice-maker-repair.html">Ice Maker Repair</a>
      </div>
      <div class="footer-col">
        <div class="footer-col__title">Brands</div>
        <a href="{ROOT}brands/sub-zero.html">Sub-Zero</a>
        <a href="{ROOT}brands/viking.html">Viking</a>
        <a href="{ROOT}brands/thermador.html">Thermador</a>
        <a href="{ROOT}brands/bosch.html">Bosch</a>
        <a href="{ROOT}brands/miele.html">Miele</a>
        <a href="{ROOT}brands/wolf.html">Wolf</a>
        <a href="{ROOT}brands/kitchenaid.html">KitchenAid</a>
        <a href="{ROOT}brands/lg.html">LG</a>
        <a href="{ROOT}brands/samsung.html">Samsung</a>
        <a href="{ROOT}brands/ge.html">GE</a>
      </div>
      <div class="footer-col">
        <div class="footer-col__title">Company</div>
        <a href="{ROOT}index.html">Home</a>
        <a href="{ROOT}services/index.html">All Services</a>
        <a href="{ROOT}brands/index.html">All Brands</a>
        <a href="{ROOT}contact.html">Contact Us</a>
      </div>
    </div>
    <div class="footer-bottom">
      <p>
        &copy; 2025 Carlsbad A-Tech. All rights reserved. Licensed &amp;
        Insured.
      </p>
      <p>Serving San Diego County, California</p>
    </div>
  </div>
</footer>
```

## Standard CTA Section HTML

```html
<section class="cta-section" id="request-service">
  <div class="container">
    <h2>Request Appliance Repair Service in San Diego</h2>
    <p>
      Fill out the form below and our team will contact you within 30 minutes
      during business hours.
    </p>
    <form class="form form--centered" action="#" method="post">
      <div class="form__row">
        <div class="form__group">
          <label for="cta-name" class="form__label">Your Name</label>
          <input
            type="text"
            id="cta-name"
            name="name"
            class="form__input"
            placeholder="John Smith"
            required
          />
          <p class="form__error">Please enter your name</p>
        </div>
        <div class="form__group">
          <label for="cta-phone" class="form__label">Phone Number</label>
          <input
            type="tel"
            id="cta-phone"
            name="phone"
            class="form__input"
            placeholder="(760) 555-0000"
            required
          />
          <p class="form__error">Please enter a valid phone number</p>
        </div>
      </div>
      <div class="form__group">
        <label for="cta-service" class="form__label">Service Needed</label>
        <select id="cta-service" name="service" class="form__select" required>
          <option value="">Select a service...</option>
          <option value="refrigerator">Refrigerator Repair</option>
          <option value="washer">Washer Repair</option>
          <option value="dryer">Dryer Repair</option>
          <option value="oven">Oven Repair</option>
          <option value="stove">Stove Repair</option>
          <option value="kitchen-range">Kitchen Range Repair</option>
          <option value="dishwasher">Dishwasher Repair</option>
          <option value="microwave">Microwave Repair</option>
          <option value="freezer">Freezer Repair</option>
          <option value="ice-maker">Ice Maker Repair</option>
          <option value="other">Other</option>
        </select>
        <p class="form__error">Please select a service</p>
      </div>
      <button type="submit" class="btn btn--primary btn--large btn--block">
        Request Service in San Diego
      </button>
    </form>
  </div>
</section>
```

## Standard FAQ Section HTML Pattern

```html
<section class="section" id="faq">
  <div class="container">
    <h2 class="section__title">Frequently Asked Questions</h2>
    <div class="faq">
      <div class="faq__item">
        <button class="faq__question" aria-expanded="false">
          Question text here?
          <span class="faq__icon">+</span>
        </button>
        <div class="faq__answer">
          <p>Answer text here.</p>
        </div>
      </div>
      <!-- Repeat for each Q&A -->
    </div>
  </div>
</section>
```

## JSON-LD Patterns

### FAQPage (every page)

```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Question?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Answer."
      }
    }
  ]
}
```

### LocalBusiness (Home + Contact only)

```json
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Carlsbad A-Tech",
  "description": "Professional appliance repair serving San Diego County, CA. Certified technicians for all major brands.",
  "telephone": "+1-760-555-0137",
  "email": "service@carlsbadatech.com",
  "url": "https://carlsbadatech.com",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Carlsbad",
    "addressRegion": "CA",
    "addressCountry": "US"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": "33.1581",
    "longitude": "-117.3506"
  },
  "areaServed": {
    "@type": "County",
    "name": "San Diego County",
    "containedInPlace": {
      "@type": "State",
      "name": "California"
    }
  },
  "openingHoursSpecification": [
    {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday"
      ],
      "opens": "08:00",
      "closes": "18:00"
    }
  ],
  "priceRange": "$$"
}
```

### BreadcrumbList (all child pages)

```json
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://carlsbadatech.com/"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "{SECTION}",
      "item": "https://carlsbadatech.com/{section}/"
    },
    { "@type": "ListItem", "position": 3, "name": "{PAGE_NAME}" }
  ]
}
```

### Service (service pages only)

```json
{
  "@context": "https://schema.org",
  "@type": "Service",
  "serviceType": "{SERVICE_NAME} Repair",
  "provider": {
    "@type": "LocalBusiness",
    "name": "Carlsbad A-Tech",
    "telephone": "+1-760-555-0137"
  },
  "areaServed": {
    "@type": "County",
    "name": "San Diego County",
    "containedInPlace": { "@type": "State", "name": "California" }
  },
  "description": "{Service description}"
}
```

## Image Naming Convention

- Services: `{service}-repair-san-diego-1.webp`, `{service}-repair-san-diego-2.webp`
- Brands: `{brand}-appliance-repair-san-diego-1.webp`, `{brand}-appliance-repair-san-diego-2.webp`
- Alt format: `{Service/Brand} Repair in San Diego — Carlsbad A-Tech`

## Cross-linking Rules

- Service pages → link to 3-4 relevant brands
- Brand pages → link to 3-4 relevant services
- All pages → link to Home via breadcrumbs + logo
- Hub pages → link to all their children

## Brand ↔ Service Mapping (for cross-links)

| Brand      | Primary Services                              |
| ---------- | --------------------------------------------- |
| Sub-Zero   | Refrigerator, Freezer, Ice Maker              |
| Dacor      | Oven, Stove, Kitchen Range, Dishwasher        |
| Viking     | Kitchen Range, Oven, Refrigerator, Dishwasher |
| Thermador  | Oven, Stove, Kitchen Range, Dishwasher        |
| Gaggenau   | Oven, Dishwasher, Refrigerator, Freezer       |
| Bosch      | Dishwasher, Washer, Dryer, Refrigerator       |
| Miele      | Dishwasher, Washer, Dryer, Oven               |
| Wolf       | Kitchen Range, Oven, Stove, Microwave         |
| KitchenAid | Dishwasher, Refrigerator, Oven, Microwave     |
| Jenn-Air   | Kitchen Range, Oven, Refrigerator, Dishwasher |
| LG         | Washer, Dryer, Refrigerator, Dishwasher       |
| Maytag     | Washer, Dryer, Dishwasher, Refrigerator       |
| Samsung    | Refrigerator, Washer, Dryer, Dishwasher       |
| GE         | Refrigerator, Oven, Dishwasher, Washer        |
